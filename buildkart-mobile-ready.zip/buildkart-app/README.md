# BuildKart

Construction materials marketplace — compare vendor prices, book delivery, GST invoicing (with buyer-selectable ITC/composition scheme), order tracking with live delivery-partner map, vendor subscriptions + payouts, inventory management, buyer/vendor OTP login, real Razorpay payments, ratings & reviews, admin/ops dashboard, refund/dispute flow, multi-address support, the Plix assistant, and multi-language support.

## 📱 Convert to Mobile App (iOS + Android)

This project is ready to become a real mobile app using **Capacitor**.

👉 **See full instructions in [MOBILE_SETUP.md](./MOBILE_SETUP.md)**

Quick start:

```bash
npm install
npx cap add android
npx cap add ios          # Mac only
npm run mobile:sync
npm run mobile:android   # opens Android Studio
npm run mobile:ios       # opens Xcode (Mac only)
```

---

## Run locally (Web)

```bash
npm install
npm run dev
```

Opens at http://localhost:5173

## Deploy — GitHub Pages (automatic, on every push)

This repo includes a GitHub Actions workflow (`.github/workflows/deploy.yml`) that builds and publishes the app automatically every time you push to `main`. One-time setup:

1. Push this repo to GitHub (if you haven't already).
2. On GitHub, go to your repo → **Settings** → **Pages** (left sidebar).
3. Under **Build and deployment → Source**, choose **GitHub Actions** (not "Deploy from a branch").
4. Push any commit to `main` — the workflow runs automatically. Watch progress under the **Actions** tab.
5. Once it finishes (green checkmark), your live URL appears at the top of the **Settings → Pages** screen — usually `https://your-username.github.io/your-repo-name/`.

From then on, every push to `main` redeploys automatically — no manual build step needed on your end.

## Deploy — Vercel (recommended, free tier)

1. Go to https://vercel.com and sign up / log in (GitHub login is easiest).
2. Click **Add New → Project**.
3. Choose **"Upload"** if you don't want to use GitHub, and drag this whole folder in.
3. Under **Build and deployment → Source**, choose **GitHub Actions** (not "Deploy from a branch").
4. Push any commit to `main` — the workflow runs automatically. Watch progress under the **Actions** tab.
5. Once it finishes (green checkmark), your live URL appears at the top of the **Settings → Pages** screen — usually `https://your-username.github.io/your-repo-name/`.

From then on, every push to `main` redeploys automatically — no manual build step needed on your end.

## Deploy — Vercel (recommended, free tier)

1. Go to https://vercel.com and sign up / log in (GitHub login is easiest).
2. Click **Add New → Project**.
3. Choose **"Upload"** if you don't want to use GitHub, and drag this whole folder in.
   - Or, push this folder to a GitHub repo and click **Import Project** instead.
4. Vercel auto-detects Vite. Leave the defaults:
   - Build command: `npm run build`
   - Output directory: `dist`
5. Click **Deploy**. You'll get a live URL like `buildkart.vercel.app` in about a minute.

## Deploy — Netlify (also free, drag-and-drop friendly)

1. Run these locally first to generate the production build:
   ```bash
   npm install
   npm run build
   ```
   This creates a `dist` folder.
2. Go to https://app.netlify.com/drop
3. Drag the `dist` folder onto the page. It deploys instantly with a live URL.

## Notes before real-world use

This is currently a **frontend-only prototype** — products, vendors, orders, reviews, and notifications reset every time the page reloads, and no two visitors share the same data. Before onboarding real vendors and buyers, you'll need:

- A real database (e.g. Postgres/Supabase) for products, vendors, orders, subscriptions, payouts, reviews, and disputes — this is the single biggest gap right now
- Real SMS/OTP gateway (e.g. MSG91, Twilio Verify, Firebase Phone Auth) — OTPs are currently shown on-screen for testing
- Real vendor KYC/GSTIN verification (e.g. Karza, Signzy) — GSTIN format is checked, but not verified against government records
- A payout/split-payment partner (Razorpay Route, Cashfree Vendor Payouts) to actually move money to vendor bank accounts
- The platform's own GST registration and 1% TCS compliance as an "e-commerce operator" under Indian GST law — get a CA's sign-off before collecting real commission
- Business registration (LLP/Pvt Ltd) plus real Terms of Service, Privacy Policy, and Refund Policy
- Real admin authentication (the current admin passcode is a demo-only placeholder)
- A real delivery solution — either your own rider fleet with GPS tracking, or a logistics partner — current tracking is simulated

See `CHANGELOG.md` for the full feature history.
