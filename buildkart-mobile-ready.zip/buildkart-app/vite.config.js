import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // Relative base so the built assets resolve correctly whether this is served
  // from a domain root (Vercel) or a GitHub Pages project subfolder
  // (https://username.github.io/repo-name/).
  base: "./",
});
