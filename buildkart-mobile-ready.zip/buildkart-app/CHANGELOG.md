# Changelog

All notable changes to BuildKart are recorded here. Dates reflect when each change was made in development, not a public release schedule. This file is source-repo documentation only and is never shown in the app UI.

## [1.13.3] - 2026-08-01
### Changed
- Removed the map preview from the location/address picker entirely (catalog page and cart's delivery site section) — it now shows text only, even while actively changing the address. The map is now shown **only** on the "My Orders" tracking screen, once an order is dispatched, matching what it's actually for: watching the delivery rider's route, not confirming a pin.

## [1.13.2] - 2026-08-01
### Fixed
- Location map preview no longer shows permanently on the front/catalog page — it now only appears while actively changing the address (manual entry open, or the saved-addresses picker open), keeping the front page clean.

## [1.13.1] - 2026-07-31
### Added
- GitHub Actions workflow (`.github/workflows/deploy.yml`) — automatically builds and deploys to GitHub Pages on every push to `main`.
- `vite.config.js` now uses a relative base path so builds work correctly on both Vercel and GitHub Pages without changes.
### Notes
- One-time setup required: repo Settings → Pages → set Source to "GitHub Actions". After that, every push auto-deploys.

## [1.13.0] - 2026-07-30
### Added
- **Plix** — a rule-based assistant (floating chat button, both buyer and vendor pages) that answers structured questions using the app's own local data: order status/tracking, refund status, payment charges, and price drops for buyers; last payout ("credit"), platform fees deducted ("debit"), stock alerts, and subscription renewal for vendors.
- **Multi-language support** — language switcher (globe icon in header) covering 10 languages: English, Hindi, Tamil, Telugu, Kannada, Malayalam, Bengali, Marathi, Gujarati, Punjabi. Translated: navigation tabs, search placeholder, delivery address label, cart totals, checkout button, buyer sign-in screen, vendor dashboard header/buttons.
### Notes
- Plix is intentionally NOT a general conversational AI — that requires a real LLM API call routed through a backend (to keep the API key out of the browser), which this prototype doesn't have. Plix's pattern-matching approach is fast, works offline, and is accurate for the specific things it's built to answer, but won't handle open-ended conversation.
- Language coverage is a first pass on the highest-visibility strings — not every string in the app yet. Translations should be reviewed by a native speaker of each language before a real public launch.

## [1.12.0] - 2026-07-28
### Added
- **Order history & reorder** — one-tap "Reorder" on any past order, re-adding every line to cart (skipping items no longer offered).
- **Ratings** — buyers rate vendors and products after delivery (star rating + comment). Vendor/product ratings blend real reviews with the seed rating, weighted so one review doesn't swing it wildly.
- **Price range & rating filters** on the catalog page.
- **Notifications** — bell icon in the header for order status changes and price drops on previously-ordered items.
- **Admin/ops dashboard** — demo passcode-gated "Admin" mode with platform GMV, platform revenue, vendors ranked by revenue, and an open-disputes queue with approve/reject actions.
- **Refund & dispute flow** — cancelling before dispatch triggers an immediate simulated refund; post-delivery issues go into an admin-reviewed dispute queue.
- **Multi-address support** — save multiple delivery addresses with labels, switch between them at checkout.
### Notes
- Admin passcode is a demo-only gate — not real authentication.

## [1.11.0] - 2026-07-24
### Added
- Real payment gateway integration (Razorpay Checkout) for UPI, Card, and Net Banking.
- Developer "test with ₹1" toggle at checkout.
- Payment failure/dismissal handling with visible error messages.
### Changed
- `ProductCard` wrapped in `React.memo` for catalog rendering performance.
### Notes
- Requires a real Razorpay Key ID — test keys need no KYC, live keys require Razorpay business KYC.
- No backend yet — all state is per-browser-session only.

## [1.10.0] - 2026-07-24
### Added
- Real client-side invoice PDF generation (jsPDF) once an order is delivered.
- "Share PDF" via the native Web Share API (WhatsApp/Mail/etc.), plus pre-filled fallback links.
- Optional email field at buyer login to support the email fallback.

## [1.9.0] - 2026-07-23
### Added
- Buyer mobile + OTP login (demo mode), logout control.
- Real map-based delivery location picker: live GPS or manual address + landmark, geocoded via Nominatim, with a map pin confirmation.

## [1.8.0] - 2026-07-23
### Added
- Live delivery-partner tracking map (Leaflet + OpenStreetMap), simulated rider position based on order stage, with a "Call rider" action.

## [1.7.1] - 2026-07-23
### Added
- Version/date metadata (source comments + `package.json` + this changelog); a quiet console log on load, never shown on the visible page.

## [1.7.0] - 2026-07-23
### Changed
- Updated GST rates to CBIC Notification No. 14/2025 ("GST 2.0"): cement 28% → 18%; bricks corrected from an outdated 5% to the real 12% (with ITC) / 6% (composition scheme).
### Added
- Buyer-selectable GST scheme at checkout (12% with ITC vs 6% composition), recalculating cart totals, tax invoice, and vendor payouts.

## [1.6.0] - 2026-07-22
### Added
- Brick quantity estimator: upload a layout sketch/photo/PDF, enter wall measurements, get an instant bricks-required calculation with full breakdown.
- OCR-based dimension auto-detection (Tesseract.js + pdf.js) for photos and PDFs.

## [1.5.0] - 2026-07-22
### Added
- Real-time buyer location via browser Geolocation API + reverse geocoding.

## [1.4.0] - 2026-07-21/22
### Added
- Vendor subscription plans, bank account onboarding, automatic per-order payout calculation with platform commission, Earnings & Payouts panel with a full viability breakdown.
- Rupee-level price breakup (base + GST = total) in cart and tax invoice.

## [1.3.0] - 2026-07-21
### Added
- Vendor mobile + OTP authentication, with GSTIN matching to recognize returning vendors.

## [1.2.0] - 2026-07-20/21
### Added
- Vendor inventory management: stock status, freshness tracking, low-stock alerts, quick restock.
- "Fresh stock" badge and buyer-facing ranking incentive for vendors who keep stock updated.

## [1.1.0] - 2026-07-20
### Added
- Vendor product CRUD, GST/HSN details with CGST/SGST breakdown, order tracking (4-stage delivery tracker).

## [1.0.0] - 2026-07-20
### Added
- Initial working prototype: buyer catalog with multi-vendor price comparison, cart, checkout, delivery booking, basic vendor dashboard.
- Branding finalized as "BuildKart" with a custom crane-and-brick icon mark.
