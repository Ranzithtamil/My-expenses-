import React from "react";
import ReactDOM from "react-dom/client";
import BuildKart from "./App.jsx";
import "./index.css";
import "leaflet/dist/leaflet.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BuildKart />
  </React.StrictMode>
);
