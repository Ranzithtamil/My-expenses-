/**
 * BuildKart — Construction Materials Marketplace
 * -------------------------------------------------
 * Version:      1.13.3
 * Last updated: 23 July 2026
 * Author:       Ranzith, S/O K. Lakshmipathi
 *
 * This header is source-code metadata only. The version/date below is logged
 * to the browser console on load (visible only in Developer Tools) for support
 * and debugging purposes — it is never rendered anywhere on the visible page.
 * See CHANGELOG.md in the project root for the full version history.
 */

import { useState, useMemo, useEffect, useRef, memo } from "react";
import {
  Search, MapPin, Truck, ShoppingCart, Plus, Minus, X, Check,
  Package, TrendingDown, Star, ChevronRight, Building2, Wallet,
  Banknote, CreditCard, Landmark, ClipboardList, Store, ArrowLeft,
  Pencil, Trash2, Save, PackagePlus, FileText, CircleDot, ListOrdered,
  AlertTriangle, Clock, RefreshCw, Zap, Upload, Ruler, Calculator, ImagePlus,
  Bell, ShieldCheck, MessageCircle, Send, Globe,
} from "lucide-react";

const APP_VERSION = "1.13.3";
const APP_UPDATED = "23 July 2026";

// ---------- Multi-language support ----------
// First pass: covers navigation, core actions, and checkout labels — the
// highest-visibility strings a buyer/vendor sees constantly. Not every string
// in the app is translated yet; screen-by-screen content (product names,
// vendor names, form help text) stays in English for now. Translations below
// are a solid starting point but should be reviewed by a native speaker of
// each language before a real public launch.
const LANGUAGES = [
  { code: "en", label: "English" },
  { code: "hi", label: "हिन्दी" },
  { code: "ta", label: "தமிழ்" },
  { code: "te", label: "తెలుగు" },
  { code: "kn", label: "ಕನ್ನಡ" },
  { code: "ml", label: "മലയാളം" },
  { code: "bn", label: "বাংলা" },
  { code: "mr", label: "मराठी" },
  { code: "gu", label: "ગુજરાતી" },
  { code: "pa", label: "ਪੰਜਾਬੀ" },
];

const TRANSLATIONS = {
  buyer: { en: "Buyer", hi: "खरीदार", ta: "வாங்குபவர்", te: "కొనుగోలుదారు", kn: "ಖರೀದಿದಾರ", ml: "വാങ്ങുന്നയാൾ", bn: "ক্রেতা", mr: "खरेदीदार", gu: "ખરીદનાર", pa: "ਖਰੀਦਦਾਰ" },
  vendor: { en: "Vendor", hi: "विक्रेता", ta: "விற்பனையாளர்", te: "విక్రేత", kn: "ಮಾರಾಟಗಾರ", ml: "വിൽപ്പനക്കാരൻ", bn: "বিক্রেতা", mr: "विक्रेता", gu: "વિક્રેતા", pa: "ਵਿਕਰੇਤਾ" },
  admin: { en: "Admin", hi: "एडमिन", ta: "நிர்வாகி", te: "అడ్మిన్", kn: "ನಿರ್ವಾಹಕ", ml: "അഡ്മിൻ", bn: "অ্যাডমিন", mr: "प्रशासक", gu: "એડમિન", pa: "ਐਡਮਿਨ" },
  search_placeholder: {
    en: "Search bricks, cement, TMT bars...", hi: "ईंट, सीमेंट, टीएमटी बार खोजें...", ta: "செங்கல், சிமெண்ட், டிஎம்டி தேடுங்கள்...",
    te: "ఇటుకలు, సిమెంట్, టీఎంటీ వెతకండి...", kn: "ಇಟ್ಟಿಗೆ, ಸಿಮೆಂಟ್, ಟಿಎಂಟಿ ಹುಡುಕಿ...", ml: "ഇഷ്ടിക, സിമന്റ്, ടിഎംടി തിരയുക...",
    bn: "ইট, সিমেন্ট, টিএমটি খুঁজুন...", mr: "वीट, सिमेंट, टीएमटी शोधा...", gu: "ઈંટ, સિમેન્ટ, ટીએમટી શોધો...", pa: "ਇੱਟ, ਸੀਮੈਂਟ, ਟੀਐਮਟੀ ਖੋਜੋ...",
  },
  delivering_to: { en: "Delivering to", hi: "डिलीवरी पता", ta: "விநியோக முகவரி", te: "డెలివరీ చిరునామా", kn: "ವಿತರಣಾ ವಿಳಾಸ", ml: "ഡെലിവറി വിലാസം", bn: "ডেলিভারি ঠিকানা", mr: "वितरण पत्ता", gu: "ડિલિવરી સરનામું", pa: "ਡਿਲੀਵਰੀ ਪਤਾ" },
  add: { en: "ADD", hi: "जोड़ें", ta: "சேர்", te: "జోడించు", kn: "ಸೇರಿಸಿ", ml: "ചേർക്കുക", bn: "যোগ করুন", mr: "जोडा", gu: "ઉમેરો", pa: "ਸ਼ਾਮਲ ਕਰੋ" },
  view_cart: { en: "Review", hi: "समीक्षा करें", ta: "மதிப்பாய்வு", te: "సమీక్షించండి", kn: "ಪರಿಶೀಲಿಸಿ", ml: "അവലോകനം ചെയ്യുക", bn: "পর্যালোচনা", mr: "पुनरावलोकन", gu: "સમીક્ષા", pa: "ਸਮੀਖਿਆ" },
  subtotal: { en: "Materials subtotal", hi: "सामग्री उप-योग", ta: "பொருட்கள் துணைத்தொகை", te: "మెటీరియల్స్ సబ్‌టోటల్", kn: "ವಸ್ತುಗಳ ಉಪಮೊತ್ತ", ml: "സാധനങ്ങളുടെ ഉപആകെത്തുക", bn: "উপকরণ উপ-মোট", mr: "साहित्य उप-बेरीज", gu: "સામગ્રી પેટા-કુલ", pa: "ਸਮੱਗਰੀ ਉਪ-ਜੋੜ" },
  total_payable: { en: "Total payable", hi: "कुल देय राशि", ta: "மொத்த தொகை", te: "మొత్తం చెల్లించవలసినది", kn: "ಒಟ್ಟು ಪಾವತಿಸಬೇಕಾದ ಮೊತ್ತ", ml: "ആകെ അടയ്‌ക്കേണ്ട തുക", bn: "মোট প্রদেয়", mr: "एकूण देय", gu: "કુલ ચૂકવવાપાત્ર", pa: "ਕੁੱਲ ਭੁਗਤਾਨਯੋਗ" },
  confirm_book: { en: "Confirm & book delivery", hi: "पुष्टि करें और डिलीवरी बुक करें", ta: "உறுதிசெய்து விநியோகத்தை பதிவு செய்யுங்கள்", te: "నిర్ధారించి డెలివరీ బుక్ చేయండి", kn: "ದೃಢೀಕರಿಸಿ ಮತ್ತು ವಿತರಣೆ ಬುಕ್ ಮಾಡಿ", ml: "സ്ഥിരീകരിച്ച് ഡെലിവറി ബുക്ക് ചെയ്യുക", bn: "নিশ্চিত করুন এবং ডেলিভারি বুক করুন", mr: "पुष्टी करा आणि डिलिव्हरी बुक करा", gu: "પુષ્ટિ કરો અને ડિલિવરી બુક કરો", pa: "ਪੁਸ਼ਟੀ ਕਰੋ ਅਤੇ ਡਿਲੀਵਰੀ ਬੁੱਕ ਕਰੋ" },
  sign_in: { en: "Sign in to order", hi: "ऑर्डर करने के लिए साइन इन करें", ta: "ஆர்டர் செய்ய உள்நுழையவும்", te: "ఆర్డర్ చేయడానికి సైన్ ఇన్ చేయండి", kn: "ಆರ್ಡರ್ ಮಾಡಲು ಸೈನ್ ಇನ್ ಮಾಡಿ", ml: "ഓർഡർ ചെയ്യാൻ സൈൻ ഇൻ ചെയ്യുക", bn: "অর্ডার করতে সাইন ইন করুন", mr: "ऑर्डर करण्यासाठी साइन इन करा", gu: "ઓર્ડર કરવા માટે સાઇન ઇન કરો", pa: "ਆਰਡਰ ਕਰਨ ਲਈ ਸਾਈਨ ਇਨ ਕਰੋ" },
  send_otp: { en: "Send OTP", hi: "ओटीपी भेजें", ta: "OTP அனுப்பவும்", te: "OTP పంపండి", kn: "OTP ಕಳುಹಿಸಿ", ml: "OTP അയയ്ക്കുക", bn: "OTP পাঠান", mr: "OTP पाठवा", gu: "OTP મોકલો", pa: "OTP ਭੇਜੋ" },
  my_orders: { en: "My orders", hi: "मेरे ऑर्डर", ta: "எனது ஆர்டர்கள்", te: "నా ఆర్డర్‌లు", kn: "ನನ್ನ ಆರ್ಡರ್‌ಗಳು", ml: "എന്റെ ഓർഡറുകൾ", bn: "আমার অর্ডার", mr: "माझ्या ऑर्डर", gu: "મારા ઓર્ડર", pa: "ਮੇਰੇ ਆਰਡਰ" },
  vendor_dashboard: { en: "Vendor dashboard", hi: "विक्रेता डैशबोर्ड", ta: "விற்பனையாளர் டாஷ்போர்டு", te: "విక్రేత డాష్‌బోర్డ్", kn: "ಮಾರಾಟಗಾರ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್", ml: "വിൽപ്പനക്കാരന്റെ ഡാഷ്ബോർഡ്", bn: "বিক্রেতা ড্যাশবোর্ড", mr: "विक्रेता डॅशबोर्ड", gu: "વિક્રેતા ડેશબોર્ડ", pa: "ਵਿਕਰੇਤਾ ਡੈਸ਼ਬੋਰਡ" },
  add_product: { en: "Add product", hi: "उत्पाद जोड़ें", ta: "தயாரிப்பைச் சேர்", te: "ఉత్పత్తిని జోడించండి", kn: "ಉತ್ಪನ್ನ ಸೇರಿಸಿ", ml: "ഉൽപ്പന്നം ചേർക്കുക", bn: "পণ্য যোগ করুন", mr: "उत्पादन जोडा", gu: "ઉત્પાદન ઉમેરો", pa: "ਉਤਪਾਦ ਸ਼ਾਮਲ ਕਰੋ" },
  log_out: { en: "Log out", hi: "लॉग आउट", ta: "வெளியேறு", te: "లాగ్ అవుట్", kn: "ಲಾಗ್ ಔಟ್", ml: "ലോഗ് ഔട്ട്", bn: "লগ আউট", mr: "लॉग आउट", gu: "લૉગ આઉટ", pa: "ਲਾਗ ਆਊਟ" },
};

function useTranslate(lang) {
  return (key) => TRANSLATIONS[key]?.[lang] || TRANSLATIONS[key]?.en || key;
}

// ---------- Design tokens ----------
const COLORS = {
  charcoal: "#20241F",
  concrete: "#EDEAE2",
  concreteDark: "#DCD7CB",
  steel: "#3D5A73",
  orange: "#E1611F",
  yellow: "#F0B429",
  ink: "#2A2B26",
};

// ---------- Seed data ----------
// GST rates per CBIC Notification No. 14/2025-Central Tax (Rate), effective 22 Sep 2025 ("GST 2.0" reform).
// gst = standard rate (with full Input Tax Credit). Bricks additionally support a
// vendor-selectable composition scheme at a lower rate but without ITC (see gstCompositionRate).
const CATEGORIES = [
  { id: "bricks", name: "Bricks & Blocks", unit: "per 1000 pcs", hsn: "6901", gst: 12, gstCompositionRate: 6, hasGstScheme: true, lowStock: 5000, restockStep: 5000 },
  { id: "aggregate", name: "Crusher & Aggregate", unit: "per ton", hsn: "2517", gst: 5, lowStock: 100, restockStep: 100 },
  { id: "steel", name: "Steel / TMT Bars", unit: "per ton", hsn: "7214", gst: 18, lowStock: 10, restockStep: 10 },
  { id: "cement", name: "Cement", unit: "per bag", hsn: "2523", gst: 18, lowStock: 300, restockStep: 200 },
  { id: "sand", name: "Sand", unit: "per ton", hsn: "2505", gst: 5, lowStock: 100, restockStep: 100 },
];

const hAgo = (h) => new Date(Date.now() - h * 3600 * 1000);
const dAgo = (d) => new Date(Date.now() - d * 24 * 3600 * 1000); // negative d = a date in the future

const SUBSCRIPTION_PLANS = [
  { id: "starter", name: "Starter", price: 499, cycle: "month", listingCap: 20, features: ["Up to 20 listings", "Standard search placement", "Email support"] },
  { id: "growth", name: "Growth", price: 1499, cycle: "month", listingCap: 200, features: ["Up to 200 listings", "Priority search placement", "Fresh-stock boost eligible", "Phone + email support"] },
  { id: "enterprise", name: "Enterprise", price: 4999, cycle: "month", listingCap: Infinity, features: ["Unlimited listings", "Top search placement", "Multi-location support", "Dedicated account manager"] },
];

const INITIAL_VENDORS = [
  {
    id: "v1", name: "Shree Balaji Traders", rating: 4.6, deliveryDays: 1, gstin: "29ABCDE1234F1Z5",
    lat: 13.0475, lng: 80.2824, // T. Nagar, Chennai
    subscription: { planId: "growth", status: "active", startedAt: dAgo(20), renewsAt: dAgo(-10) },
    bankAccount: { holderName: "Shree Balaji Traders", accountNumber: "003401567890", ifsc: "HDFC0000034", bankName: "HDFC Bank", verified: true },
  },
  {
    id: "v2", name: "Kumar Building Supplies", rating: 4.3, deliveryDays: 2, gstin: "29PQRSX5678K1Z2",
    lat: 13.0067, lng: 80.2206, // Guindy, Chennai
    subscription: { planId: "starter", status: "active", startedAt: dAgo(5), renewsAt: dAgo(-25) },
    bankAccount: { holderName: "Kumar Building Supplies", accountNumber: "011201234567", ifsc: "ICIC0001120", bankName: "ICICI Bank", verified: true },
  },
  {
    id: "v3", name: "New Era Materials Co.", rating: 4.8, deliveryDays: 1, gstin: "29LMNOP9012L1Z8",
    lat: 12.9915, lng: 80.2337, // Adyar, Chennai
    subscription: { planId: "enterprise", status: "active", startedAt: dAgo(60), renewsAt: dAgo(-5) },
    bankAccount: { holderName: "New Era Materials Co.", accountNumber: "500123456789", ifsc: "SBIN0005001", bankName: "State Bank of India", verified: true },
  },
  {
    id: "v4", name: "Ganesh Hardware & Steel", rating: 4.1, deliveryDays: 3, gstin: "29GHIJK3456M1Z1",
    lat: 13.0850, lng: 80.2101, // Anna Nagar, Chennai
    subscription: { planId: "starter", status: "active", startedAt: dAgo(2), renewsAt: dAgo(-28) },
    bankAccount: { holderName: "Ganesh Hardware & Steel", accountNumber: "020098765432", ifsc: "AXIS0000200", bankName: "Axis Bank", verified: true },
  },
];

// Simulated delivery riders assigned once an order is dispatched (no real fleet backend yet).
const DELIVERY_PARTNERS = [
  { name: "Suresh Kumar", vehicle: "Tata Ace mini-truck", phone: "+91 98765 43210" },
  { name: "Manikandan R", vehicle: "Pickup truck", phone: "+91 91234 56789" },
  { name: "Vijay S", vehicle: "Mini lorry", phone: "+91 99887 66554" },
];
// Progress along the route (0 = at vendor, 1 = arrived) shown per tracking stage.
const STAGE_PROGRESS = [0, 0.15, 0.7, 1];

const INITIAL_PRODUCTS = [
  { id: "p1", cat: "bricks", name: "Red Clay Bricks (Class-A)", offers: [
    { vendorId: "v1", price: 6200, stock: 40000, updatedAt: hAgo(2), gstScheme: "itc" },
    { vendorId: "v2", price: 6450, stock: 60000, updatedAt: dAgo(5), gstScheme: "composition" },
    { vendorId: "v3", price: 6100, stock: 25000, updatedAt: hAgo(0.5), gstScheme: "itc" },
  ]},
  { id: "p2", cat: "bricks", name: "Fly Ash Bricks", offers: [
    { vendorId: "v2", price: 5400, stock: 50000, updatedAt: dAgo(1), gstScheme: "composition" },
    { vendorId: "v4", price: 5600, stock: 30000, updatedAt: dAgo(6), gstScheme: "itc" },
  ]},
  { id: "p3", cat: "aggregate", name: "Crushed Stone 20mm", offers: [
    { vendorId: "v1", price: 950, stock: 500, updatedAt: hAgo(3) },
    { vendorId: "v3", price: 890, stock: 300, updatedAt: dAgo(10) },
    { vendorId: "v4", price: 970, stock: 700, updatedAt: hAgo(1) },
  ]},
  { id: "p4", cat: "aggregate", name: "Crusher Dust (M-Sand base)", offers: [
    { vendorId: "v2", price: 700, stock: 400, updatedAt: dAgo(2) },
    { vendorId: "v3", price: 680, stock: 350, updatedAt: hAgo(4) },
  ]},
  { id: "p5", cat: "steel", name: "TMT Bar Fe-500 (12mm)", offers: [
    { vendorId: "v1", price: 62000, stock: 8, updatedAt: dAgo(3) },
    { vendorId: "v3", price: 61200, stock: 35, updatedAt: hAgo(5) },
    { vendorId: "v4", price: 63000, stock: 15, updatedAt: dAgo(3) },
  ]},
  { id: "p6", cat: "steel", name: "Binding Wire / Steel Needles", offers: [
    { vendorId: "v2", price: 78000, stock: 5, updatedAt: hAgo(6) },
    { vendorId: "v4", price: 76500, stock: 8, updatedAt: hAgo(12) },
  ]},
  { id: "p7", cat: "cement", name: "OPC 53 Grade Cement", offers: [
    { vendorId: "v1", price: 385, stock: 2000, updatedAt: hAgo(1) },
    { vendorId: "v2", price: 375, stock: 1800, updatedAt: dAgo(2) },
    { vendorId: "v3", price: 390, stock: 2500, updatedAt: hAgo(0.3) },
  ]},
  { id: "p8", cat: "sand", name: "River Sand (Fine)", offers: [
    { vendorId: "v1", price: 1600, stock: 0, updatedAt: dAgo(10) },
    { vendorId: "v4", price: 1550, stock: 250, updatedAt: dAgo(7) },
  ]},
];

const PAYMENT_METHODS = [
  { id: "upi", label: "UPI", icon: Wallet, sub: "Google Pay, PhonePe, Paytm", gateway: true },
  { id: "card", label: "Card", icon: CreditCard, sub: "Credit / Debit card", gateway: true },
  { id: "cod", label: "Cash on Delivery", icon: Banknote, sub: "Pay at site", gateway: false },
  { id: "netbank", label: "Net Banking", icon: Landmark, sub: "All major banks", gateway: true },
];

// --- Real payment gateway config ---
// Replace with your own Razorpay Key ID (Dashboard → Settings → API Keys).
// Test keys (rzp_test_...) need no KYC and process no real money — perfect for validating
// this integration. Live keys (rzp_live_...) require Razorpay KYC approval and move real rupees.
const RAZORPAY_KEY_ID = "rzp_test_REPLACE_WITH_YOUR_KEY";

function loadRazorpayScript() {
  return new Promise((resolve, reject) => {
    if (window.Razorpay) return resolve();
    const existing = document.getElementById("razorpay-checkout-js");
    if (existing) {
      existing.addEventListener("load", () => resolve());
      existing.addEventListener("error", () => reject(new Error("Failed to load Razorpay script")));
      return;
    }
    const script = document.createElement("script");
    script.id = "razorpay-checkout-js";
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Failed to load Razorpay script"));
    document.body.appendChild(script);
  });
}

// Opens the real Razorpay checkout modal (UPI/Card/Netbanking tabs built in).
// amountRupees is charged as-is — pass 1 to genuinely test with ₹1 instead of the full cart total.
async function openRazorpayCheckout({ amountRupees, buyerMobile, buyerName, onSuccess, onFailure, onDismiss }) {
  if (RAZORPAY_KEY_ID.includes("REPLACE_WITH_YOUR_KEY")) {
    onFailure("No Razorpay key configured yet. Add your test/live Key ID to RAZORPAY_KEY_ID in the source code first.");
    return;
  }
  try {
    await loadRazorpayScript();
  } catch {
    onFailure("Couldn't load the payment gateway. Check your internet connection and try again.");
    return;
  }

  const rzp = new window.Razorpay({
    key: RAZORPAY_KEY_ID,
    amount: Math.round(amountRupees * 100), // paise
    currency: "INR",
    name: "BuildKart",
    description: "Construction materials order",
    prefill: { contact: buyerMobile || "", name: buyerName || "" },
    theme: { color: "#E1611F" },
    handler: (response) => onSuccess(response),
    modal: { ondismiss: () => onDismiss && onDismiss() },
  });
  rzp.on("payment.failed", (response) => onFailure(response.error?.description || "Payment failed. Please try again."));
  rzp.open();
}

const TRACK_STAGES = ["Confirmed", "Dispatched", "Out for delivery", "Delivered"];
const GSTIN_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
const MOBILE_REGEX = /^[6-9]\d{9}$/;
const IFSC_REGEX = /^[A-Z]{4}0[A-Z0-9]{6}$/;
const PLATFORM_COMMISSION_PCT = 3;
// Standard Indian construction estimate: bricks needed per cu.ft of brickwork
// (assumes modular brick ~9x4.5x3in with 10mm mortar joints) — a widely used rule of thumb.
const BRICKS_PER_CUFT = 13.5;

const fmt = (n) => "₹" + n.toLocaleString("en-IN", { maximumFractionDigits: 2 });
const vendorById = (vendors, id) => vendors.find((v) => v.id === id);
const catById = (id) => CATEGORIES.find((c) => c.id === id);

// Returns the actual GST % that applies to a given offer, accounting for the
// vendor's chosen scheme on categories that support one (currently: bricks).
function effectiveGstPct(offer, cat) {
  if (cat.hasGstScheme && offer.gstScheme === "composition") return cat.gstCompositionRate;
  return cat.gst;
}
const planById = (id) => SUBSCRIPTION_PLANS.find((p) => p.id === id);

function timeAgo(date) {
  const mins = Math.floor((Date.now() - new Date(date).getTime()) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}
const isFreshStock = (date) => Date.now() - new Date(date).getTime() < 24 * 3600 * 1000;

function stockStatus(offer, cat) {
  if (offer.stock <= 0) return "out";
  if (offer.stock <= cat.lowStock) return "low";
  return "ok";
}

// Blends real buyer reviews with the vendor's starting seed rating, so ratings
// aren't reset to zero the moment reviews are introduced, but genuinely shift
// as real reviews come in.
function liveVendorRating(vendor, reviews) {
  const vendorReviews = reviews.filter((r) => r.targetType === "vendor" && r.targetId === vendor.id);
  if (vendorReviews.length === 0) return vendor.rating;
  const reviewAvg = vendorReviews.reduce((s, r) => s + r.rating, 0) / vendorReviews.length;
  // Weight the seed rating as if it were 5 reviews, so one new review doesn't swing it wildly.
  return (vendor.rating * 5 + reviewAvg * vendorReviews.length) / (5 + vendorReviews.length);
}
function productRating(productId, reviews) {
  const productReviews = reviews.filter((r) => r.targetType === "product" && r.targetId === productId);
  if (productReviews.length === 0) return null;
  return productReviews.reduce((s, r) => s + r.rating, 0) / productReviews.length;
}

// ---------- Root ----------
export default function BuildKart() {
  useEffect(() => {
    // Developer/support info only — visible in browser console (DevTools), never on the page itself.
    console.log(`%cBuildKart v${APP_VERSION}%c — last updated ${APP_UPDATED}`, "font-weight:bold;color:#E1611F;", "color:inherit;");
  }, []);

  const [mode, setMode] = useState("buyer"); // buyer | vendor | admin
  const [language, setLanguage] = useState("en");
  const t = useTranslate(language);
  const [screen, setScreen] = useState("catalog"); // catalog | cart | confirm | orders
  const [activeCat, setActiveCat] = useState("bricks");
  const [query, setQuery] = useState("");
  const [priceMin, setPriceMin] = useState("");
  const [priceMax, setPriceMax] = useState("");
  const [minRating, setMinRating] = useState(0);
  const [cart, setCart] = useState({});
  const [gstChoices, setGstChoices] = useState({}); // cart key -> "itc" | "composition", buyer's own choice
  const [payment, setPayment] = useState(null);
  const [gstin, setGstin] = useState("");
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState(INITIAL_PRODUCTS);
  const [vendors, setVendors] = useState(INITIAL_VENDORS);
  const [vendorSession, setVendorSession] = useState(null); // {id, mobile, gstin, verified}
  const [buyerSession, setBuyerSession] = useState(null); // {mobile, name}
  const [payouts, setPayouts] = useState([]);
  const [lastOrderId, setLastOrderId] = useState(null);
  const [reviews, setReviews] = useState([]); // {id, orderId, vendorId, productId, rating, comment, date}
  const [notifications, setNotifications] = useState([]); // {id, type, message, date, read}
  const [savedAddresses, setSavedAddresses] = useState([]); // {id, label, address, landmark, lat, lng}
  const [disputes, setDisputes] = useState([]); // {id, orderId, reason, status, date}
  const [adminUnlocked, setAdminUnlocked] = useState(false);
  const [location, setLocation] = useState({
    label: "Chennai, Tamil Nadu",
    address: "Construction site, Chennai, Tamil Nadu",
    lat: 13.0827,
    lng: 80.2707,
    status: "default", // default | locating | live | error
    error: null,
  });

  function requestLiveLocation() {
    if (!navigator.geolocation) {
      setLocation((prev) => ({ ...prev, status: "error", error: "Location isn't supported on this device/browser." }));
      return;
    }
    setLocation((prev) => ({ ...prev, status: "locating", error: null }));
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`
          );
          const data = await res.json();
          const a = data.address || {};
          // Build the most granular address possible from individual components,
          // rather than relying only on the (sometimes verbose) full display_name.
          const streetPart = [a.house_number, a.road].filter(Boolean).join(" ");
          const areaPart = a.suburb || a.neighbourhood || a.quarter || "";
          const city = a.city || a.town || a.village || a.county || "Your area";
          const state = a.state || "";
          const postcode = a.postcode || "";

          const preciseLabel = [streetPart, areaPart].filter(Boolean).join(", ") || city;
          const fullAddress =
            [streetPart, areaPart, city, state, postcode].filter(Boolean).join(", ") ||
            data.display_name ||
            `${city}, ${state}`;

          setLocation({
            label: preciseLabel,
            address: fullAddress,
            lat: latitude,
            lng: longitude,
            accuracy,
            status: "live",
            error: null,
          });
        } catch {
          setLocation({
            label: `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`,
            address: `Exact coordinates: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`,
            lat: latitude,
            lng: longitude,
            accuracy,
            status: "live",
            error: null,
          });
        }
      },
      (err) => {
        const msg =
          err.code === err.PERMISSION_DENIED
            ? "Location access was denied. You can allow it in your browser/site settings, or continue with the default site address."
            : "Couldn't get your location right now. Try again in a moment.";
        setLocation((prev) => ({ ...prev, status: "error", error: msg }));
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  }

  // Buyer manually enters an address + landmark; we geocode it to real coordinates
  // so the same delivery-tracking map can plot it, instead of relying only on live GPS.
  async function setManualAddress(addressText, landmarkText) {
    setLocation((prev) => ({ ...prev, status: "locating", error: null }));
    try {
      const query = landmarkText ? `${addressText}, ${landmarkText}` : addressText;
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(query)}`
      );
      const data = await res.json();
      if (data && data[0]) {
        const { lat, lon, display_name } = data[0];
        setLocation({
          label: display_name.split(",").slice(0, 2).join(",").trim(),
          address: landmarkText ? `${addressText} (Landmark: ${landmarkText})` : addressText,
          lat: Number(lat),
          lng: Number(lon),
          status: "live",
          error: null,
        });
      } else {
        setLocation((prev) => ({
          ...prev,
          status: "error",
          error: "Couldn't find that address. Try adding more detail or a nearby landmark.",
        }));
      }
    } catch {
      setLocation((prev) => ({ ...prev, status: "error", error: "Couldn't look up that address right now." }));
    }
  }

  function buyerLogin({ mobile, name }) {
    setBuyerSession({ mobile, name });
  }
  function buyerLogout() {
    setBuyerSession(null);
  }

  const filteredProducts = useMemo(() => {
    const min = priceMin ? Number(priceMin) : null;
    const max = priceMax ? Number(priceMax) : null;
    return products.filter((p) => {
      if (p.cat !== activeCat) return false;
      if (!p.name.toLowerCase().includes(query.toLowerCase())) return false;
      const inStockOffers = p.offers.filter((o) => o.stock > 0);
      const relevantOffers = inStockOffers.length ? inStockOffers : p.offers;
      const lowestPrice = Math.min(...relevantOffers.map((o) => o.price));
      if (min != null && lowestPrice < min) return false;
      if (max != null && lowestPrice > max) return false;
      if (minRating > 0) {
        const bestRating = Math.max(...relevantOffers.map((o) => liveVendorRating(vendorById(vendors, o.vendorId) || { rating: 0 }, reviews)));
        if (bestRating < minRating) return false;
      }
      return true;
    });
  }, [activeCat, query, products, priceMin, priceMax, minRating, vendors, reviews]);

  function addToCart(productId, vendorId, delta) {
    const key = `${productId}__${vendorId}`;
    setCart((prev) => {
      const next = { ...prev };
      const cur = next[key] || 0;
      const val = Math.max(0, cur + delta);
      if (val === 0) delete next[key];
      else next[key] = val;
      return next;
    });
  }

  function setGstChoice(key, scheme) {
    setGstChoices((prev) => ({ ...prev, [key]: scheme }));
  }

  const cartLines = useMemo(() => {
    return Object.entries(cart).map(([key, qty]) => {
      const [productId, vendorId] = key.split("__");
      const product = products.find((p) => p.id === productId);
      const offer = product.offers.find((o) => o.vendorId === vendorId);
      const vendor = vendorById(vendors, vendorId);
      const cat = catById(product.cat);
      // Buyer's own choice takes priority; falls back to the vendor's listed scheme, then ITC by default.
      const gstScheme = cat.hasGstScheme ? (gstChoices[key] || offer.gstScheme || "itc") : null;
      const gstPct = cat.hasGstScheme ? (gstScheme === "composition" ? cat.gstCompositionRate : cat.gst) : cat.gst;
      return { key, product, offer, vendor, cat, qty, gstScheme, gstPct };
    });
  }, [cart, products, vendors, gstChoices]);

  const cartCount = cartLines.reduce((s, l) => s + l.qty, 0);
  const subtotal = cartLines.reduce((s, l) => s + l.qty * l.offer.price, 0);
  const gstTotal = cartLines.reduce((s, l) => s + (l.qty * l.offer.price * l.gstPct) / 100, 0);
  const deliveryFee = cartLines.length ? 250 : 0;
  const grandTotal = subtotal + gstTotal + deliveryFee;

  function placeOrder() {
    const originVendor = cartLines[0].vendor;
    const deliveryPartner = DELIVERY_PARTNERS[Math.floor(Math.random() * DELIVERY_PARTNERS.length)];

    const newOrder = {
      id: "BM" + Math.floor(100000 + Math.random() * 900000),
      invoiceNo: "INV-" + new Date().getFullYear() + "-" + Math.floor(1000 + Math.random() * 9000),
      date: new Date(),
      lines: cartLines,
      subtotal,
      gstTotal,
      deliveryFee,
      total: grandTotal,
      payment,
      buyerGstin: gstin.trim() || null,
      stage: 0,
      status: "active", // active | cancelled
      refundStatus: null, // null | refunded | dispute_open | dispute_rejected
      refundedAt: null,
      etaDays: Math.max(...cartLines.map((l) => l.vendor.deliveryDays)),
      deliveryPartner,
      originLat: originVendor.lat,
      originLng: originVendor.lng,
      destLat: location.lat,
      destLng: location.lng,
      destLabel: location.label,
    };
    setOrders((prev) => [newOrder, ...prev]);

    // Settle payment directly to each vendor's linked bank account, minus platform commission
    const byVendor = {};
    cartLines.forEach((l) => {
      const gross = l.qty * l.offer.price * (1 + l.gstPct / 100);
      byVendor[l.vendor.id] = (byVendor[l.vendor.id] || 0) + gross;
    });
    const newPayouts = Object.entries(byVendor).map(([vendorId, gross]) => {
      const commission = gross * (PLATFORM_COMMISSION_PCT / 100);
      return {
        id: "PO" + Math.floor(100000 + Math.random() * 900000),
        orderId: newOrder.id,
        vendorId,
        gross,
        commission,
        net: gross - commission,
        date: new Date(),
        status: "credited",
      };
    });
    setPayouts((prev) => [...newPayouts, ...prev]);

    setScreen("confirm");
    setCart({});
    setPayment(null);
    setGstin("");
    // stash last order id for confirm screen
    setLastOrderId(newOrder.id);
  }

  const lastOrder = orders.find((o) => o.id === lastOrderId);

  function pushNotification(type, message) {
    setNotifications((prev) => [{ id: "N" + Date.now() + Math.random().toString(36).slice(2, 6), type, message, date: new Date(), read: false }, ...prev]);
  }
  function markAllNotificationsRead() {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }

  function advanceOrderStage(orderId) {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== orderId) return o;
        const nextStage = Math.min(o.stage + 1, TRACK_STAGES.length - 1);
        pushNotification("status", `Order ${o.id} is now "${TRACK_STAGES[nextStage]}".`);
        return { ...o, stage: nextStage };
      })
    );
  }

  // Vendor auto-login: matches an existing vendor by GSTIN, or provisions a new
  // vendor profile on the spot from just a mobile number (+ optional GSTIN).
  function vendorLogin({ mobile, gstinInput }) {
    const cleanGstin = gstinInput.trim().toUpperCase();
    const matchedByGstin = cleanGstin ? vendors.find((v) => v.gstin === cleanGstin) : null;
    const matchedByMobile = !matchedByGstin ? vendors.find((v) => v.mobile === mobile) : null;
    const matched = matchedByGstin || matchedByMobile;

    if (matched) {
      setVendors((prev) => prev.map((v) => (v.id === matched.id ? { ...v, mobile, gstin: cleanGstin || v.gstin } : v)));
      setVendorSession({ id: matched.id, mobile, gstin: cleanGstin || matched.gstin, verified: !!(cleanGstin || matched.gstin), isNew: false });
      return;
    }

    const newId = "v" + Date.now();
    const newVendor = {
      id: newId,
      name: "New Vendor " + mobile.slice(-4),
      rating: 0,
      deliveryDays: 2,
      gstin: cleanGstin || null,
      mobile,
      subscription: null,
      bankAccount: null,
    };
    setVendors((prev) => [...prev, newVendor]);
    setVendorSession({ id: newId, mobile, gstin: cleanGstin || null, verified: !!cleanGstin, isNew: true });
  }

  function activateSubscription(vendorId, planId) {
    setVendors((prev) =>
      prev.map((v) =>
        v.id === vendorId
          ? { ...v, subscription: { planId, status: "active", startedAt: new Date(), renewsAt: dAgo(-30) } }
          : v
      )
    );
  }

  function saveBankAccount(vendorId, bankAccount) {
    setVendors((prev) => prev.map((v) => (v.id === vendorId ? { ...v, bankAccount: { ...bankAccount, verified: true } } : v)));
  }

  function vendorLogout() {
    setVendorSession(null);
  }

  function addProduct(newProd) {
    setProducts((prev) => [...prev, newProd]);
  }
  function updateOffer(productId, vendorId, changes) {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id !== productId) return p;
        return {
          ...p,
          offers: p.offers.map((o) => {
            if (o.vendorId !== vendorId) return o;
            if ("price" in changes && changes.price < o.price) {
              const everOrdered = orders.some((ord) => ord.lines.some((l) => l.product.id === productId && l.vendor.id === vendorId));
              if (everOrdered) {
                pushNotification("price_drop", `Price drop: ${p.name} is now ${fmt(changes.price)} (was ${fmt(o.price)}) at ${vendorById(vendors, vendorId)?.name || "a vendor"}.`);
              }
            }
            return { ...o, ...changes, updatedAt: new Date() };
          }),
        };
      })
    );
  }
  function deleteOffer(productId, vendorId) {
    setProducts((prev) =>
      prev
        .map((p) =>
          p.id !== productId ? p : { ...p, offers: p.offers.filter((o) => o.vendorId !== vendorId) }
        )
        .filter((p) => p.offers.length > 0)
    );
  }

  // Re-adds every line from a past order back into the cart, skipping any
  // line whose vendor no longer carries that product (out-of-catalog since).
  function reorder(order) {
    let skipped = 0;
    order.lines.forEach((l) => {
      const product = products.find((p) => p.id === l.product.id);
      const stillOffered = product?.offers.some((o) => o.vendorId === l.vendor.id);
      if (stillOffered) {
        addToCart(l.product.id, l.vendor.id, l.qty);
      } else {
        skipped++;
      }
    });
    if (skipped > 0) {
      pushNotification("status", `${skipped} item(s) from that order are no longer available and were skipped.`);
    }
    setScreen("cart");
  }

  function submitReview(orderId, targetType, targetId, rating, comment) {
    setReviews((prev) => [
      ...prev,
      { id: "R" + Date.now(), orderId, targetType, targetId, rating, comment, date: new Date() },
    ]);
  }

  // Cancelling before dispatch auto-refunds immediately (simulated) — matches
  // how most marketplaces handle pre-shipment cancellations.
  function cancelOrder(orderId) {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== orderId) return o;
        pushNotification("status", `Order ${o.id} was cancelled and ${fmt(o.total)} has been refunded.`);
        return { ...o, status: "cancelled", refundStatus: "refunded", refundedAt: new Date() };
      })
    );
    setPayouts((prev) => prev.map((p) => (p.orderId === orderId ? { ...p, status: "reversed" } : p)));
  }

  // For issues found after delivery — goes into a queue for admin review rather
  // than an automatic refund, since these need a human judgment call.
  function raiseDispute(orderId, reason) {
    setDisputes((prev) => [
      ...prev,
      { id: "D" + Date.now(), orderId, reason, status: "open", date: new Date() },
    ]);
    setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, refundStatus: "dispute_open" } : o)));
    pushNotification("status", `Dispute raised for order ${orderId}. Our team will review it.`);
  }

  function resolveDispute(disputeId, approve) {
    setDisputes((prev) =>
      prev.map((d) => (d.id === disputeId ? { ...d, status: approve ? "approved" : "rejected" } : d))
    );
    setDisputes((prevAll) => {
      const dispute = prevAll.find((d) => d.id === disputeId);
      if (dispute) {
        setOrders((prev) =>
          prev.map((o) => {
            if (o.id !== dispute.orderId) return o;
            if (approve) pushNotification("status", `Refund approved for order ${o.id} — ${fmt(o.total)} refunded.`);
            return { ...o, refundStatus: approve ? "refunded" : "dispute_rejected", refundedAt: approve ? new Date() : o.refundedAt };
          })
        );
        if (approve) {
          setPayouts((prev) => prev.map((p) => (p.orderId === dispute.orderId ? { ...p, status: "reversed" } : p)));
        }
      }
      return prevAll;
    });
  }

  function saveCurrentAddress(label) {
    setSavedAddresses((prev) => [
      ...prev,
      { id: "A" + Date.now(), label: label || "Saved address", address: location.address, landmark: "", lat: location.lat, lng: location.lng },
    ]);
  }
  function selectSavedAddress(addressId) {
    const a = savedAddresses.find((x) => x.id === addressId);
    if (!a) return;
    setLocation({ label: a.label, address: a.address, lat: a.lat, lng: a.lng, status: "live", error: null });
  }
  function deleteSavedAddress(addressId) {
    setSavedAddresses((prev) => prev.filter((a) => a.id !== addressId));
  }

  return (
    <div style={{ background: COLORS.concrete, fontFamily: "'Barlow', 'Inter', sans-serif" }} className="min-h-screen text-[15px]">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800&family=Barlow:wght@400;500;600&family=JetBrains+Mono:wght@500;700&display=swap');
        .disp { font-family: 'Barlow Condensed', sans-serif; letter-spacing: 0.01em; }
        .mono { font-family: 'JetBrains Mono', monospace; }
      `}</style>

      <Header mode={mode} setMode={setMode} setScreen={setScreen} cartCount={cartCount} screen={screen} buyerSession={buyerSession} onBuyerLogout={buyerLogout} notifications={notifications} onMarkAllRead={markAllNotificationsRead} language={language} setLanguage={setLanguage} t={t} />

      {mode === "buyer" && !buyerSession && (
        <BuyerLogin onLogin={buyerLogin} t={t} />
      )}

      {mode === "buyer" && buyerSession && screen === "catalog" && (
        <Catalog
          query={query} setQuery={setQuery} activeCat={activeCat} setActiveCat={setActiveCat}
          products={filteredProducts} allProducts={products} vendors={vendors} cart={cart} addToCart={addToCart}
          cartCount={cartCount} cartTotal={subtotal} onOpenCart={() => setScreen("cart")}
          location={location} onRequestLocation={requestLiveLocation} onManualAddress={setManualAddress}
          priceMin={priceMin} setPriceMin={setPriceMin} priceMax={priceMax} setPriceMax={setPriceMax}
          minRating={minRating} setMinRating={setMinRating} reviews={reviews}
          savedAddresses={savedAddresses} onSaveAddress={saveCurrentAddress} onSelectAddress={selectSavedAddress} onDeleteAddress={deleteSavedAddress}
          t={t}
        />
      )}

      {mode === "buyer" && buyerSession && screen === "cart" && (
        <CartScreen
          lines={cartLines} addToCart={addToCart} subtotal={subtotal} gstTotal={gstTotal}
          deliveryFee={deliveryFee} grandTotal={grandTotal} payment={payment} setPayment={setPayment}
          gstin={gstin} setGstin={setGstin} onBack={() => setScreen("catalog")} onPlaceOrder={placeOrder}
          location={location} onRequestLocation={requestLiveLocation} onManualAddress={setManualAddress} onSetGstChoice={setGstChoice}
          buyerSession={buyerSession}
          savedAddresses={savedAddresses} onSaveAddress={saveCurrentAddress} onSelectAddress={selectSavedAddress} onDeleteAddress={deleteSavedAddress}
          t={t}
        />
      )}

      {mode === "buyer" && buyerSession && screen === "confirm" && lastOrder && (
        <ConfirmScreen order={lastOrder} onDone={() => setScreen("catalog")} onTrack={() => setScreen("orders")} />
      )}

      {mode === "buyer" && buyerSession && screen === "orders" && (
        <OrdersScreen
          orders={orders} onAdvance={advanceOrderStage} onBack={() => setScreen("catalog")} buyerSession={buyerSession}
          onReorder={reorder} onCancel={cancelOrder} onSubmitReview={submitReview} onRaiseDispute={raiseDispute} reviews={reviews}
        />
      )}

      {mode === "vendor" && !vendorSession && (
        <VendorLogin onLogin={vendorLogin} />
      )}

      {mode === "vendor" && vendorSession && (() => {
        const activeVendor = vendorById(vendors, vendorSession.id);
        if (!activeVendor) return null;

        if (!activeVendor.subscription || activeVendor.subscription.status !== "active") {
          return (
            <SubscriptionScreen
              vendor={activeVendor}
              onSubscribe={(planId) => activateSubscription(vendorSession.id, planId)}
              onLogout={vendorLogout}
            />
          );
        }
        if (!activeVendor.bankAccount) {
          return (
            <BankAccountScreen
              vendor={activeVendor}
              onSave={(bank) => saveBankAccount(vendorSession.id, bank)}
              onLogout={vendorLogout}
            />
          );
        }
        return (
          <VendorPanel
            products={products} vendors={vendors} vendorId={vendorSession.id} session={vendorSession}
            payouts={payouts.filter((p) => p.vendorId === vendorSession.id)}
            addProduct={addProduct} updateOffer={updateOffer} deleteOffer={deleteOffer} onLogout={vendorLogout}
            t={t}
          />
        );
      })()}

      {mode === "admin" && (
        <AdminDashboard
          unlocked={adminUnlocked} onUnlock={() => setAdminUnlocked(true)}
          vendors={vendors} products={products} orders={orders} payouts={payouts}
          disputes={disputes} onResolveDispute={resolveDispute} reviews={reviews}
        />
      )}

      {mode === "buyer" && buyerSession && (
        <PlixAssistant role="buyer" buyerCtx={{ orders, notifications }} vendorCtx={{}} />
      )}
      {mode === "vendor" && vendorSession && (() => {
        const activeVendor = vendorById(vendors, vendorSession.id);
        return (
          <PlixAssistant
            role="vendor"
            buyerCtx={{}}
            vendorCtx={{
              payouts: payouts.filter((p) => p.vendorId === vendorSession.id),
              products,
              vendorId: vendorSession.id,
              subscription: activeVendor?.subscription || null,
            }}
          />
        );
      })()}
    </div>
  );
}

// ---------- Admin / ops dashboard ----------
const ADMIN_DEMO_PASSCODE = "buildkart-admin"; // demo-only gate, not real auth — see note in the dashboard itself

function AdminDashboard({ unlocked, onUnlock, vendors, products, orders, payouts, disputes, onResolveDispute, reviews }) {
  const [passcode, setPasscode] = useState("");
  const [error, setError] = useState("");

  if (!unlocked) {
    return (
      <div className="max-w-md mx-auto px-4 pt-12 pb-16">
        <div className="text-center mb-6">
          <div style={{ background: COLORS.charcoal }} className="w-14 h-14 rounded-full mx-auto flex items-center justify-center mb-3">
            <ShieldCheck size={24} color="white" />
          </div>
          <div className="disp text-2xl font-800" style={{ color: COLORS.ink }}>Admin access</div>
          <div className="text-sm mt-1" style={{ color: COLORS.ink + "80" }}>Platform operations — vendors, orders, disputes.</div>
        </div>
        <div className="bg-white rounded-lg border border-black/5 p-4 space-y-3">
          <input
            type="password" value={passcode} onChange={(e) => { setPasscode(e.target.value); setError(""); }}
            placeholder="Admin passcode" className="w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2"
            style={{ "--tw-ring-color": COLORS.orange }}
          />
          {error && <div className="text-[11px]" style={{ color: COLORS.orange }}>{error}</div>}
          <button
            onClick={() => (passcode === ADMIN_DEMO_PASSCODE ? onUnlock() : setError("Incorrect passcode."))}
            style={{ background: COLORS.orange }} className="w-full text-white rounded-lg py-3 font-bold text-sm"
          >
            Unlock
          </button>
          <div className="text-[10px]" style={{ color: COLORS.ink + "60" }}>
            Demo-only gate (passcode: <span className="mono">{ADMIN_DEMO_PASSCODE}</span>) — not real authentication. A production build needs a real admin login tied to a backend role check.
          </div>
        </div>
      </div>
    );
  }

  const totalVendors = vendors.length;
  const totalProducts = products.length;
  const activeOrders = orders.filter((o) => o.status !== "cancelled");
  const gmv = activeOrders.reduce((s, o) => s + o.total, 0);
  const platformRevenue = payouts.filter((p) => p.status === "credited").reduce((s, p) => s + p.commission, 0);
  const openDisputes = disputes.filter((d) => d.status === "open");

  const vendorStats = vendors.map((v) => {
    const vOrders = activeOrders.filter((o) => o.lines.some((l) => l.vendor.id === v.id));
    const revenue = vOrders.reduce((s, o) => s + o.lines.filter((l) => l.vendor.id === v.id).reduce((s2, l) => s2 + l.qty * l.offer.price, 0), 0);
    return { vendor: v, orderCount: vOrders.length, revenue, rating: liveVendorRating(v, reviews) };
  }).sort((a, b) => b.revenue - a.revenue);

  return (
    <div className="max-w-5xl mx-auto px-4 pb-16">
      <div className="pt-5 pb-4">
        <div className="text-xs font-semibold mb-1" style={{ color: COLORS.steel }}>OPERATIONS DASHBOARD</div>
        <div className="disp text-2xl font-800" style={{ color: COLORS.ink }}>Platform overview</div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <StatCard label="Vendors" value={totalVendors} />
        <StatCard label="Listed products" value={totalProducts} />
        <StatCard label="GMV (active orders)" value={fmt(gmv)} />
        <StatCard label="Platform revenue" value={fmt(platformRevenue)} />
      </div>

      {openDisputes.length > 0 && (
        <div className="mb-6">
          <div className="disp text-sm font-700 uppercase tracking-wide mb-2 flex items-center gap-1.5" style={{ color: COLORS.orange }}>
            <AlertTriangle size={13} /> Open disputes ({openDisputes.length})
          </div>
          <div className="bg-white rounded-lg border border-black/5 divide-y divide-black/5">
            {openDisputes.map((d) => {
              const order = orders.find((o) => o.id === d.orderId);
              return (
                <div key={d.id} className="p-4">
                  <div className="text-sm font-semibold" style={{ color: COLORS.ink }}>Order {d.orderId}{order ? ` — ${fmt(order.total)}` : ""}</div>
                  <div className="text-xs mt-1" style={{ color: COLORS.ink + "80" }}>{d.reason}</div>
                  <div className="text-[10px] mt-1" style={{ color: COLORS.ink + "60" }}>Filed {timeAgo(d.date)}</div>
                  <div className="flex gap-2 mt-2.5">
                    <button onClick={() => onResolveDispute(d.id, true)} style={{ background: COLORS.orange }} className="text-white text-xs font-bold rounded-md px-3 py-1.5">
                      Approve refund
                    </button>
                    <button onClick={() => onResolveDispute(d.id, false)} className="text-xs font-bold rounded-md px-3 py-1.5 border" style={{ borderColor: COLORS.ink + "20", color: COLORS.ink + "80" }}>
                      Reject
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="disp text-sm font-700 uppercase tracking-wide mb-2" style={{ color: COLORS.steel }}>Vendors by revenue</div>
      <div className="bg-white rounded-lg border border-black/5 divide-y divide-black/5">
        {vendorStats.map(({ vendor, orderCount, revenue, rating }) => (
          <div key={vendor.id} className="flex items-center justify-between px-4 py-3">
            <div>
              <div className="text-sm font-semibold" style={{ color: COLORS.ink }}>{vendor.name}</div>
              <div className="text-[11px] flex items-center gap-2" style={{ color: COLORS.ink + "70" }}>
                <span className="flex items-center gap-0.5"><Star size={10} fill={COLORS.steel} color={COLORS.steel} /> {rating.toFixed(1)}</span>
                <span>{orderCount} order(s)</span>
              </div>
            </div>
            <div className="mono font-bold text-sm" style={{ color: COLORS.orange }}>{fmt(revenue)}</div>
          </div>
        ))}
      </div>

      <div className="mt-4 text-xs px-1" style={{ color: COLORS.ink + "60" }}>
        This dashboard reads the same local order/vendor data as the rest of the app — once a real backend is in place, this becomes the platform's true operational view across every vendor and buyer, not just this browser session.
      </div>
    </div>
  );
}

// ---------- Brand mark (icon + wordmark logo) ----------
// ---------- Plix — rule-based assistant (buyer + vendor) ----------
// Plix answers structured questions (order status, refunds, payouts, stock)
// by looking up the app's own local data. It is NOT a general conversational
// AI — that would need a real LLM API call through a backend (to keep an API
// key out of the browser), which this prototype doesn't have yet. This is a
// genuinely useful, honestly-scoped starting point: fast, offline, and
// accurate for the specific things it's built to answer.
function answerPlixQuery(rawText, ctx) {
  const text = rawText.toLowerCase();
  const has = (...words) => words.some((w) => text.includes(w));

  if (ctx.role === "buyer") {
    const orders = ctx.orders || [];
    const latest = orders[0];

    if (has("hi", "hello", "hey", "help", "vanakkam", "namaste")) {
      return "Hi, I'm Plix! Ask me things like \"where is my order\", \"is my refund done\", or \"any price drops\".";
    }
    if (has("refund", "cancel", "credit")) {
      const refunded = orders.find((o) => o.refundStatus === "refunded");
      if (refunded) return `Order ${refunded.id} was refunded — ${fmt(refunded.total)} credited back to you.`;
      const disputeOpen = orders.find((o) => o.refundStatus === "dispute_open");
      if (disputeOpen) return `Order ${disputeOpen.id}'s dispute is still under review — no refund credited yet.`;
      return "I don't see any refunds on your account right now.";
    }
    if (has("debit", "charged", "paid", "payment")) {
      if (!latest) return "You haven't placed any orders yet, so nothing's been charged.";
      return `Your most recent order ${latest.id} charged ${fmt(latest.total)} via ${PAYMENT_METHODS.find((p) => p.id === latest.payment)?.label || latest.payment}.`;
    }
    if (has("price drop", "cheaper", "price fell")) {
      const drop = (ctx.notifications || []).find((n) => n.type === "price_drop");
      return drop ? drop.message : "No price drops on your ordered items yet — I'll notify you the moment one happens.";
    }
    if (has("track", "where", "status", "deliver")) {
      if (!latest) return "You don't have any orders yet — place one from the catalog and I can track it for you.";
      return `Order ${latest.id} is currently "${TRACK_STAGES[latest.stage]}"${latest.deliveryPartner ? ` with ${latest.deliveryPartner.name} (${latest.deliveryPartner.vehicle})` : ""}.`;
    }
    return "I can help with: order status, refunds, payment charges, and price drops. Try asking \"where is my order\" or \"is my refund done\".";
  }

  // vendor role
  const payouts = ctx.payouts || [];
  const products = ctx.products || [];
  const vendorId = ctx.vendorId;
  const myListings = products.filter((p) => p.offers.some((o) => o.vendorId === vendorId));

  if (has("hi", "hello", "hey", "help", "vanakkam", "namaste")) {
    return "Hi, I'm Plix! Ask me things like \"what's my last payout\", \"any low stock\", or \"when does my plan renew\".";
  }
  if (has("credit", "payout", "earning", "settle")) {
    if (payouts.length === 0) return "No payouts yet — they'll show up here once a buyer orders your products.";
    const last = payouts[0];
    const total = payouts.filter((p) => p.status === "credited").reduce((s, p) => s + p.net, 0);
    return `Last payout: ${fmt(last.net)} credited for order ${last.orderId}. Total credited so far: ${fmt(total)}.`;
  }
  if (has("debit", "commission", "fee", "deduct")) {
    if (payouts.length === 0) return "No orders settled yet, so no commission has been deducted.";
    const totalCommission = payouts.reduce((s, p) => s + p.commission, 0);
    return `BuildKart's ${PLATFORM_COMMISSION_PCT}% platform fee has deducted ${fmt(totalCommission)} in total across your orders so far.`;
  }
  if (has("stock", "inventory", "out of")) {
    let outCount = 0, lowCount = 0;
    myListings.forEach((p) => {
      const offer = p.offers.find((o) => o.vendorId === vendorId);
      const cat = catById(p.cat);
      const status = stockStatus(offer, cat);
      if (status === "out") outCount++;
      if (status === "low") lowCount++;
    });
    if (outCount === 0 && lowCount === 0) return "All your listings look well-stocked right now.";
    return `You have ${outCount} product(s) out of stock and ${lowCount} running low — worth restocking soon.`;
  }
  if (has("subscription", "plan", "renew")) {
    if (!ctx.subscription) return "You don't have an active subscription yet.";
    const plan = planById(ctx.subscription.planId);
    const renewsInDays = Math.max(0, Math.ceil((new Date(ctx.subscription.renewsAt) - Date.now()) / (24 * 3600 * 1000)));
    return `You're on the ${plan.name} plan (${fmt(plan.price)}/${plan.cycle}), renewing in ${renewsInDays} day(s).`;
  }
  return "I can help with: payouts (credits), platform fees (debits), stock alerts, and your subscription. Try asking \"what's my last payout\" or \"any low stock\".";
}

function PlixAssistant({ role, buyerCtx, vendorCtx }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: "plix", text: "Hi, I'm Plix 👋 Ask me about orders, refunds, payouts, or stock." },
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, open]);

  function send() {
    const text = input.trim();
    if (!text) return;
    const ctx = role === "buyer" ? { role: "buyer", ...buyerCtx } : { role: "vendor", ...vendorCtx };
    const reply = answerPlixQuery(text, ctx);
    setMessages((prev) => [...prev, { role: "user", text }, { role: "plix", text: reply }]);
    setInput("");
  }

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        className="fixed bottom-5 right-4 w-14 h-14 rounded-full shadow-xl flex items-center justify-center z-40"
        style={{ background: COLORS.orange }}
        title="Ask Plix"
      >
        {open ? <X size={22} color="white" /> : <MessageCircle size={22} color="white" />}
      </button>

      {open && (
        <div className="fixed bottom-24 right-4 w-[calc(100%-2rem)] max-w-sm bg-white rounded-lg shadow-2xl border border-black/10 z-40 flex flex-col" style={{ height: 420 }}>
          <div style={{ background: COLORS.charcoal }} className="px-4 py-3 rounded-t-lg flex items-center gap-2">
            <div style={{ background: COLORS.orange }} className="w-7 h-7 rounded-full flex items-center justify-center">
              <MessageCircle size={14} color="white" />
            </div>
            <div>
              <div className="text-white text-sm font-bold leading-none">Plix</div>
              <div className="text-white/60 text-[10px] mt-0.5">BuildKart assistant</div>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto px-3 py-3 space-y-2">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className="max-w-[85%] rounded-lg px-3 py-2 text-xs"
                  style={m.role === "user" ? { background: COLORS.orange, color: "white" } : { background: COLORS.concrete, color: COLORS.ink }}
                >
                  {m.text}
                </div>
              </div>
            ))}
          </div>

          <div className="p-2.5 border-t border-black/5 flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder="Ask Plix a question..."
              className="flex-1 border border-black/10 rounded-full px-3 py-2 text-xs outline-none focus:ring-2"
              style={{ "--tw-ring-color": COLORS.orange }}
            />
            <button onClick={send} style={{ background: COLORS.orange }} className="w-9 h-9 rounded-full flex items-center justify-center shrink-0">
              <Send size={14} color="white" />
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function BrandMark({ size = 36 }) {
  return (
    <div
      style={{ background: COLORS.orange, width: size, height: size }}
      className="rounded-[10px] flex items-center justify-center shrink-0"
    >
      <svg width={size * 0.62} height={size * 0.62} viewBox="0 0 24 24" fill="none">
        {/* crane arm + hook */}
        <path d="M2 6 L22 3" stroke="white" strokeWidth="2" strokeLinecap="round" />
        <path d="M4 5.6 V13" stroke="white" strokeWidth="2" strokeLinecap="round" />
        <path d="M19.5 3.4 V8" stroke="white" strokeWidth="1.6" strokeLinecap="round" />
        <circle cx="19.5" cy="9.3" r="1.3" fill={COLORS.yellow} />
        {/* stacked brick base */}
        <rect x="3" y="14.5" width="7" height="3.2" rx="0.6" fill="white" />
        <rect x="10.6" y="14.5" width="7" height="3.2" rx="0.6" fill="white" fillOpacity="0.75" />
        <rect x="6.8" y="18.3" width="7" height="3.2" rx="0.6" fill="white" fillOpacity="0.55" />
      </svg>
    </div>
  );
}

// ---------- Header ----------
function Header({ mode, setMode, setScreen, cartCount, screen, buyerSession, onBuyerLogout, notifications, onMarkAllRead, language, setLanguage, t }) {
  const [showNotifs, setShowNotifs] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const unreadCount = notifications ? notifications.filter((n) => !n.read).length : 0;
  const currentLangLabel = LANGUAGES.find((l) => l.code === language)?.label || "English";

  return (
    <div style={{ background: COLORS.charcoal }} className="text-concrete sticky top-0 z-20">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <BrandMark />
          <div>
            <div className="disp text-white text-2xl font-800 leading-none">
              BUILD<span style={{ color: COLORS.yellow }}>KART</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <button onClick={() => setShowLangMenu((s) => !s)} className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center" title="Change language">
              <Globe size={16} color="white" />
            </button>
            {showLangMenu && (
              <div className="absolute right-0 top-11 w-40 bg-white rounded-lg shadow-xl border border-black/5 max-h-72 overflow-y-auto z-30">
                {LANGUAGES.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => { setLanguage(l.code); setShowLangMenu(false); }}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-black/5"
                    style={{ color: l.code === language ? COLORS.orange : COLORS.ink, fontWeight: l.code === language ? 700 : 400 }}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="flex bg-white/10 rounded-full p-0.5">
            <button
              onClick={() => { setMode("buyer"); setScreen("catalog"); }}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition ${mode === "buyer" ? "bg-white text-black" : "text-white/70"}`}
            >
              <ClipboardList size={14} /> {t("buyer")}
            </button>
            <button
              onClick={() => setMode("vendor")}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition ${mode === "vendor" ? "bg-white text-black" : "text-white/70"}`}
            >
              <Store size={14} /> {t("vendor")}
            </button>
            <button
              onClick={() => setMode("admin")}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition ${mode === "admin" ? "bg-white text-black" : "text-white/70"}`}
            >
              <ShieldCheck size={14} /> {t("admin")}
            </button>
          </div>

          {mode === "buyer" && buyerSession && (
            <>
              <div className="relative">
                <button
                  onClick={() => { setShowNotifs((s) => !s); if (!showNotifs) onMarkAllRead(); }}
                  className="relative w-9 h-9 rounded-full bg-white/10 flex items-center justify-center"
                >
                  <Bell size={16} color="white" />
                  {unreadCount > 0 && (
                    <span style={{ background: COLORS.orange }} className="absolute -top-1 -right-1 text-[10px] w-4 h-4 rounded-full flex items-center justify-center text-white font-bold">
                      {unreadCount}
                    </span>
                  )}
                </button>
                {showNotifs && (
                  <div className="absolute right-0 top-11 w-72 bg-white rounded-lg shadow-xl border border-black/5 max-h-80 overflow-y-auto z-30">
                    {(!notifications || notifications.length === 0) ? (
                      <div className="p-4 text-xs text-center" style={{ color: COLORS.ink + "60" }}>No notifications yet.</div>
                    ) : (
                      notifications.slice(0, 15).map((n) => (
                        <div key={n.id} className="px-3 py-2.5 border-b border-black/5 last:border-b-0">
                          <div className="text-xs" style={{ color: COLORS.ink }}>{n.message}</div>
                          <div className="text-[10px] mt-0.5" style={{ color: COLORS.ink + "50" }}>{timeAgo(n.date)}</div>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
              <button
                onClick={() => setScreen("orders")}
                className={`w-9 h-9 rounded-full flex items-center justify-center ${screen === "orders" ? "bg-white/25" : "bg-white/10"}`}
                title="My orders / track"
              >
                <ListOrdered size={16} color="white" />
              </button>
              <button
                onClick={() => setScreen("cart")}
                className="relative w-9 h-9 rounded-full bg-white/10 flex items-center justify-center"
              >
                <ShoppingCart size={16} color="white" />
                {cartCount > 0 && (
                  <span style={{ background: COLORS.orange }} className="absolute -top-1 -right-1 text-[10px] w-4 h-4 rounded-full flex items-center justify-center text-white font-bold">
                    {cartCount}
                  </span>
                )}
              </button>
              <button onClick={onBuyerLogout} title={`Signed in as ${buyerSession.mobile} — tap to log out`} className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center">
                <Check size={14} color={COLORS.yellow} />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------- Catalog ----------
// ---------- Location preview map (single pin, non-interactive) ----------
function LocationPreviewMap({ lat, lng }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const markerRef = useRef(null);
  const [mapError, setMapError] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const L = (await import("leaflet")).default;
        if (cancelled || !containerRef.current) return;

        if (mapRef.current) {
          mapRef.current.setView([lat, lng], 14);
          if (markerRef.current) markerRef.current.setLatLng([lat, lng]);
          return;
        }

        const map = L.map(containerRef.current, {
          zoomControl: false, attributionControl: true, dragging: false, scrollWheelZoom: false, doubleClickZoom: false,
        }).setView([lat, lng], 14);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: "&copy; OpenStreetMap contributors",
        }).addTo(map);
        const pinIcon = L.divIcon({
          className: "",
          html: `<div style="font-size:24px;line-height:1;">📍</div>`,
          iconSize: [24, 24],
          iconAnchor: [12, 24],
        });
        markerRef.current = L.marker([lat, lng], { icon: pinIcon }).addTo(map);
        mapRef.current = map;
      } catch {
        setMapError(true);
      }
    })();

    return () => {
      cancelled = true;
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
        markerRef.current = null;
      }
    };
  }, [lat, lng]);

  if (mapError) return null;
  return <div ref={containerRef} style={{ height: 140, borderRadius: 10, overflow: "hidden", background: COLORS.concrete }} />;
}

// ---------- Location section: live GPS, manual address+landmark, and map pin confirmation ----------
function LocationSection({ location, onRequestLocation, onManualAddress, compact, savedAddresses, onSaveAddress, onSelectAddress, onDeleteAddress, t }) {
  const [manualOpen, setManualOpen] = useState(false);
  const [addressInput, setAddressInput] = useState("");
  const [landmarkInput, setLandmarkInput] = useState("");
  const [showSaved, setShowSaved] = useState(false);
  const [saveLabel, setSaveLabel] = useState("");
  const [showSaveForm, setShowSaveForm] = useState(false);

  function submitManual() {
    if (!addressInput.trim()) return;
    onManualAddress(addressInput.trim(), landmarkInput.trim());
  }
  function submitSave() {
    if (!onSaveAddress) return;
    onSaveAddress(saveLabel.trim() || "Saved address");
    setSaveLabel("");
    setShowSaveForm(false);
  }

  return (
    <div className={compact ? "" : "mb-3"}>
      {!compact && (
        <button
          onClick={onRequestLocation}
          className="flex items-center gap-1.5 text-xs mb-1 disabled:opacity-60"
          style={{ color: COLORS.steel }}
          disabled={location.status === "locating"}
        >
          <MapPin size={13} />
          <span className="font-semibold">
            {location.status === "locating" ? "Detecting your location…" : `${t ? t("delivering_to") : "Delivering to"}: ${location.label}`}
          </span>
          {location.status === "live" && (
            <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded" style={{ background: COLORS.steel + "18", color: COLORS.steel }}>
              Live
            </span>
          )}
        </button>
      )}

      {compact && (
        <div className="flex items-start gap-2 text-sm mb-1.5" style={{ color: COLORS.ink }}>
          <MapPin size={15} className="mt-0.5 shrink-0" style={{ color: COLORS.orange }} />
          <span>{location.address}</span>
        </div>
      )}

      <div className="flex items-center gap-3 mb-2 flex-wrap">
        <button
          onClick={onRequestLocation}
          disabled={location.status === "locating"}
          className="text-[11px] font-semibold underline disabled:opacity-60"
          style={{ color: COLORS.orange }}
        >
          {location.status === "locating" ? "Detecting…" : "Use my current location"}
        </button>
        <button onClick={() => setManualOpen((o) => !o)} className="text-[11px] font-semibold underline" style={{ color: COLORS.steel }}>
          {manualOpen ? "Hide manual entry" : "Enter address & landmark"}
        </button>
        {onSaveAddress && savedAddresses && (
          <button onClick={() => setShowSaved((s) => !s)} className="text-[11px] font-semibold underline" style={{ color: COLORS.steel }}>
            Saved addresses ({savedAddresses.length})
          </button>
        )}
      </div>

      {showSaved && (
        <div className="bg-concrete rounded-lg p-3 mb-2.5 space-y-2" style={{ background: COLORS.concrete }}>
          {savedAddresses.length === 0 ? (
            <div className="text-[11px]" style={{ color: COLORS.ink + "60" }}>No saved addresses yet.</div>
          ) : (
            savedAddresses.map((a) => (
              <div key={a.id} className="flex items-center justify-between bg-white rounded-md px-3 py-2">
                <button onClick={() => onSelectAddress(a.id)} className="text-left flex-1 min-w-0">
                  <div className="text-xs font-semibold" style={{ color: COLORS.ink }}>{a.label}</div>
                  <div className="text-[10px] truncate" style={{ color: COLORS.ink + "60" }}>{a.address}</div>
                </button>
                <button onClick={() => onDeleteAddress(a.id)} className="shrink-0 ml-2">
                  <Trash2 size={13} style={{ color: COLORS.orange }} />
                </button>
              </div>
            ))
          )}
          {!showSaveForm ? (
            <button onClick={() => setShowSaveForm(true)} className="text-[11px] font-semibold underline" style={{ color: COLORS.orange }}>
              Save current address
            </button>
          ) : (
            <div className="flex gap-2">
              <input
                value={saveLabel} onChange={(e) => setSaveLabel(e.target.value)} placeholder="Label, e.g. Home, Site 2"
                className="flex-1 bg-white border border-black/10 rounded-md px-3 py-1.5 text-xs outline-none focus:ring-2"
                style={{ "--tw-ring-color": COLORS.orange }}
              />
              <button onClick={submitSave} style={{ background: COLORS.orange }} className="text-white text-xs font-bold rounded-md px-3 py-1.5">
                Save
              </button>
            </div>
          )}
        </div>
      )}

      {location.status === "error" && (
        <div className="text-[11px] mb-2" style={{ color: COLORS.orange }}>{location.error}</div>
      )}

      {manualOpen && (
        <div className="bg-concrete rounded-lg p-3 mb-2.5 space-y-2" style={{ background: COLORS.concrete }}>
          <div>
            <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>Address</label>
            <input
              value={addressInput} onChange={(e) => setAddressInput(e.target.value)}
              placeholder="e.g. Plot 49, Sree Selva Vignesh Avenue, Ayathur"
              className="w-full bg-white border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2"
              style={{ "--tw-ring-color": COLORS.orange }}
            />
          </div>
          <div>
            <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>
              Landmark <span style={{ color: COLORS.ink + "50" }}>(optional, helps the delivery rider)</span>
            </label>
            <input
              value={landmarkInput} onChange={(e) => setLandmarkInput(e.target.value)}
              placeholder="e.g. Near Amman Temple"
              className="w-full bg-white border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2"
              style={{ "--tw-ring-color": COLORS.orange }}
            />
          </div>
          <button
            onClick={submitManual}
            disabled={location.status === "locating"}
            style={{ background: COLORS.orange }}
            className="text-white text-xs font-bold rounded-md px-3 py-2 flex items-center gap-1.5 disabled:opacity-60"
          >
            <MapPin size={13} /> {location.status === "locating" ? "Finding…" : "Find on map"}
          </button>
        </div>
      )}
    </div>
  );
}

function Catalog({ query, setQuery, activeCat, setActiveCat, products, allProducts, vendors, cart, addToCart, cartCount, cartTotal, onOpenCart, location, onRequestLocation, onManualAddress, priceMin, setPriceMin, priceMax, setPriceMax, minRating, setMinRating, reviews, savedAddresses, onSaveAddress, onSelectAddress, onDeleteAddress, t }) {
  const [showFilters, setShowFilters] = useState(false);
  const filtersActive = priceMin || priceMax || minRating > 0;

  return (
    <div className="max-w-5xl mx-auto px-4 pb-28">
      <div className="pt-5 pb-3">
        <LocationSection
          location={location} onRequestLocation={onRequestLocation} onManualAddress={onManualAddress}
          savedAddresses={savedAddresses} onSaveAddress={onSaveAddress} onSelectAddress={onSelectAddress} onDeleteAddress={onDeleteAddress}
          t={t}
        />
        <div className="relative mb-2">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: COLORS.ink + "80" }} />
          <input
            value={query} onChange={(e) => setQuery(e.target.value)}
            placeholder={t("search_placeholder")}
            className="w-full bg-white rounded-lg pl-9 pr-3 py-2.5 text-sm outline-none border border-black/5 focus:ring-2"
            style={{ "--tw-ring-color": COLORS.orange }}
          />
        </div>
        <button onClick={() => setShowFilters((s) => !s)} className="text-[11px] font-semibold flex items-center gap-1" style={{ color: filtersActive ? COLORS.orange : COLORS.steel }}>
          <ChevronRight size={12} className={`transition-transform ${showFilters ? "rotate-90" : ""}`} />
          {filtersActive ? "Filters active" : "Price & rating filters"}
        </button>
        {showFilters && (
          <div className="bg-white rounded-lg border border-black/5 p-3 mt-2 flex flex-wrap gap-3 items-end">
            <div>
              <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>Min price</label>
              <input value={priceMin} onChange={(e) => setPriceMin(e.target.value.replace(/[^0-9]/g, ""))} placeholder="0" inputMode="numeric"
                className="mono w-24 border border-black/10 rounded-md px-2 py-1.5 text-sm outline-none focus:ring-2" style={{ "--tw-ring-color": COLORS.orange }} />
            </div>
            <div>
              <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>Max price</label>
              <input value={priceMax} onChange={(e) => setPriceMax(e.target.value.replace(/[^0-9]/g, ""))} placeholder="Any" inputMode="numeric"
                className="mono w-24 border border-black/10 rounded-md px-2 py-1.5 text-sm outline-none focus:ring-2" style={{ "--tw-ring-color": COLORS.orange }} />
            </div>
            <div>
              <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>Min rating</label>
              <select value={minRating} onChange={(e) => setMinRating(Number(e.target.value))} className="border border-black/10 rounded-md px-2 py-1.5 text-sm outline-none focus:ring-2 bg-white" style={{ "--tw-ring-color": COLORS.orange }}>
                <option value={0}>Any</option>
                <option value={3}>3.0+</option>
                <option value={4}>4.0+</option>
                <option value={4.5}>4.5+</option>
              </select>
            </div>
            {filtersActive && (
              <button onClick={() => { setPriceMin(""); setPriceMax(""); setMinRating(0); }} className="text-[11px] font-semibold underline" style={{ color: COLORS.orange }}>
                Clear filters
              </button>
            )}
          </div>
        )}
      </div>

      <BrickEstimator products={allProducts} vendors={vendors} addToCart={addToCart} />


      <div className="flex gap-2 overflow-x-auto pb-1 mb-4 -mx-4 px-4">
        {CATEGORIES.map((c) => (
          <button
            key={c.id} onClick={() => setActiveCat(c.id)}
            className="disp px-4 py-2 rounded-md text-sm font-700 whitespace-nowrap transition border"
            style={activeCat === c.id
              ? { background: COLORS.charcoal, color: "white", borderColor: COLORS.charcoal }
              : { background: "white", color: COLORS.ink, borderColor: "rgba(0,0,0,0.08)" }}
          >
            {c.name}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} vendors={vendors} cart={cart} addToCart={addToCart} reviews={reviews} />
        ))}
        {products.length === 0 && (
          <div className="text-center py-16 text-sm" style={{ color: COLORS.ink + "80" }}>
            No materials match that search in this category.
          </div>
        )}
      </div>

      {cartCount > 0 && (
        <button
          onClick={onOpenCart}
          style={{ background: COLORS.orange }}
          className="fixed bottom-5 left-1/2 -translate-x-1/2 w-[calc(100%-2rem)] max-w-md text-white rounded-lg py-3.5 px-5 flex items-center justify-between shadow-xl shadow-black/20"
        >
          <span className="flex items-center gap-2 font-semibold text-sm"><ShoppingCart size={16} /> {cartCount} item{cartCount > 1 ? "s" : ""}</span>
          <span className="mono font-bold text-sm">{fmt(cartTotal)} → Review</span>
        </button>
      )}
    </div>
  );
}

// ---------- Brick quantity estimator ----------
function BrickEstimator({ products, vendors, addToCart }) {
  const [open, setOpen] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);
  const [fileName, setFileName] = useState("");
  const [wallLength, setWallLength] = useState("");
  const [wallHeight, setWallHeight] = useState("10");
  const [thickness, setThickness] = useState("9"); // inches
  const [openingsPct, setOpeningsPct] = useState("12");
  const [wastagePct, setWastagePct] = useState("5");
  const [result, setResult] = useState(null);
  const [added, setAdded] = useState(false);

  // OCR state: idle | reading | done | unsupported | error
  const [ocrStatus, setOcrStatus] = useState("idle");
  const [detectedDims, setDetectedDims] = useState([]); // list of {raw, feet}
  const [ocrError, setOcrError] = useState("");

  const brickProducts = products.filter((p) => p.cat === "bricks");
  const [selectedProductId, setSelectedProductId] = useState(brickProducts[0]?.id || "");

  // Parses OCR'd text for dimension callouts in feet-inches, feet, meters, or mm,
  // and converts everything found into feet so it can be summed into a wall-length estimate.
  function parseDimensionsFromText(text) {
    const found = [];
    const feetInch = /(\d+)\s*'\s*-?\s*(\d{1,2})?\s*"?/g;
    const feetOnly = /(\d+(?:\.\d+)?)\s*(?:ft|feet)\b/gi;
    const meters = /(\d+(?:\.\d+)?)\s*m\b(?!m)/gi;
    const millimeters = /(\d+(?:\.\d+)?)\s*mm\b/gi;

    let m;
    while ((m = feetInch.exec(text)) !== null) {
      const ft = Number(m[1]) + (Number(m[2]) || 0) / 12;
      if (ft > 0.5 && ft < 200) found.push({ raw: m[0].trim(), feet: ft });
    }
    while ((m = feetOnly.exec(text)) !== null) {
      const ft = Number(m[1]);
      if (ft > 0.5 && ft < 200) found.push({ raw: m[0].trim(), feet: ft });
    }
    while ((m = meters.exec(text)) !== null) {
      const ft = Number(m[1]) * 3.28084;
      if (ft > 0.5 && ft < 200) found.push({ raw: m[0].trim(), feet: ft });
    }
    while ((m = millimeters.exec(text)) !== null) {
      const ft = Number(m[1]) / 304.8;
      if (ft > 0.5 && ft < 200) found.push({ raw: m[0].trim(), feet: ft });
    }
    return found;
  }

  async function runOcrOnImageSource(source) {
    setOcrStatus("reading");
    setOcrError("");
    try {
      const Tesseract = (await import("tesseract.js")).default;
      const { data } = await Tesseract.recognize(source, "eng");
      const dims = parseDimensionsFromText(data.text || "");
      if (dims.length > 0) {
        const total = dims.reduce((s, d) => s + d.feet, 0);
        setDetectedDims(dims);
        setWallLength(total.toFixed(1));
        setOcrStatus("done");
      } else {
        setDetectedDims([]);
        setOcrStatus("done");
      }
    } catch (err) {
      setOcrStatus("error");
      setOcrError("Couldn't scan this file automatically. Enter measurements manually below.");
    }
  }

  async function runOcrOnPdf(file) {
    setOcrStatus("reading");
    setOcrError("");
    try {
      const pdfjsLib = await import("pdfjs-dist/build/pdf.mjs");
      pdfjsLib.GlobalWorkerOptions.workerSrc =
        "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.0.379/pdf.worker.min.js";
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const page = await pdf.getPage(1);
      const viewport = page.getViewport({ scale: 2 });
      const canvas = document.createElement("canvas");
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      const ctx = canvas.getContext("2d");
      await page.render({ canvasContext: ctx, viewport }).promise;
      setImagePreview(canvas.toDataURL());
      await runOcrOnImageSource(canvas);
    } catch (err) {
      setOcrStatus("error");
      setOcrError("Couldn't read this PDF automatically. Enter measurements manually below.");
    }
  }

  function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setDetectedDims([]);
    setOcrError("");

    if (file.type.startsWith("image/")) {
      setImagePreview(URL.createObjectURL(file));
      runOcrOnImageSource(file);
    } else if (file.type === "application/pdf") {
      setImagePreview(null);
      runOcrOnPdf(file);
    } else {
      // CAD files (.dwg/.dxf) and other formats: accept the upload for reference,
      // but there's no in-browser way to read vector CAD geometry without a real backend.
      setImagePreview(null);
      setOcrStatus("unsupported");
    }
  }

  function calculate() {
    const lengthFt = Number(wallLength) || 0;
    const heightFt = Number(wallHeight) || 0;
    const thicknessFt = Number(thickness) / 12;
    const openingsFrac = (Number(openingsPct) || 0) / 100;
    const wastageFrac = (Number(wastagePct) || 0) / 100;

    const grossVolume = lengthFt * heightFt * thicknessFt;
    const netVolume = grossVolume * (1 - openingsFrac);
    const baseBricks = netVolume * BRICKS_PER_CUFT;
    const totalBricks = Math.ceil(baseBricks * (1 + wastageFrac));

    setResult({ lengthFt, heightFt, thicknessFt, grossVolume, netVolume, baseBricks, totalBricks });
    setAdded(false);
  }

  function addEstimateToCart() {
    if (!result || !selectedProductId) return;
    const product = brickProducts.find((p) => p.id === selectedProductId);
    if (!product) return;
    const cheapest = [...product.offers].filter((o) => o.stock > 0).sort((a, b) => a.price - b.price)[0];
    if (!cheapest) return;
    const unitsOf1000 = Math.ceil(result.totalBricks / 1000);
    addToCart(product.id, cheapest.vendorId, unitsOf1000);
    setAdded(true);
  }

  return (
    <div className="bg-white rounded-lg border border-black/5 mb-4 overflow-hidden">
      <button onClick={() => setOpen((o) => !o)} className="w-full flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <div style={{ background: COLORS.orange + "15" }} className="w-8 h-8 rounded-md flex items-center justify-center">
            <Calculator size={16} style={{ color: COLORS.orange }} />
          </div>
          <div className="text-left">
            <div className="disp text-sm font-700" style={{ color: COLORS.ink }}>Estimate bricks from your layout</div>
            <div className="text-[10px]" style={{ color: COLORS.ink + "60" }}>Upload a sketch or PDF, we'll try to auto-detect dimensions</div>
          </div>
        </div>
        <ChevronRight size={16} className={`transition-transform ${open ? "rotate-90" : ""}`} style={{ color: COLORS.ink + "60" }} />
      </button>

      {open && (
        <div className="px-4 pb-4 border-t border-black/5 pt-4">
          <label className="block text-xs font-semibold mb-1.5" style={{ color: COLORS.ink + "80" }}>
            Layout sketch — image, PDF, or CAD file (.jpg, .png, .heic, .pdf, .dwg, .dxf)
          </label>
          <label
            className="flex items-center justify-center gap-2 border-2 border-dashed rounded-lg py-4 mb-1 cursor-pointer"
            style={{ borderColor: COLORS.ink + "20" }}
          >
            <input
              type="file"
              accept="image/*,application/pdf,.dwg,.dxf,.heic,.heif"
              onChange={handleFile}
              className="hidden"
            />
            {imagePreview ? (
              <img src={imagePreview} alt="Layout sketch" className="max-h-32 rounded-md object-contain" />
            ) : fileName ? (
              <span className="flex items-center gap-2 text-xs font-semibold" style={{ color: COLORS.steel }}>
                <FileText size={16} /> {fileName}
              </span>
            ) : (
              <span className="flex items-center gap-2 text-xs font-semibold" style={{ color: COLORS.steel }}>
                <ImagePlus size={16} /> Tap to upload a photo, PDF, or CAD file
              </span>
            )}
          </label>

          {ocrStatus === "reading" && (
            <div className="text-[11px] mb-3 flex items-center gap-1.5" style={{ color: COLORS.steel }}>
              <RefreshCw size={11} className="animate-spin" /> Scanning for dimension labels…
            </div>
          )}

          {ocrStatus === "done" && detectedDims.length > 0 && (
            <div className="rounded-md p-2.5 mb-3 text-[11px]" style={{ background: COLORS.steel + "10", color: COLORS.steel }}>
              <div className="font-bold mb-1 flex items-center gap-1"><Zap size={11} /> Auto-detected {detectedDims.length} dimension label{detectedDims.length > 1 ? "s" : ""}</div>
              <div className="mono">{detectedDims.map((d) => d.raw).join(", ")}</div>
              <div className="mt-1">Summed into wall length below — please check it against your sketch before calculating.</div>
            </div>
          )}

          {ocrStatus === "done" && detectedDims.length === 0 && (
            <div className="text-[11px] mb-3" style={{ color: COLORS.ink + "60" }}>
              We scanned the file but didn't find clear dimension labels (like 12' or 3.6m) on it. Enter wall length manually below.
            </div>
          )}

          {ocrStatus === "unsupported" && (
            <div className="text-[11px] mb-3 flex items-start gap-1.5" style={{ color: COLORS.ink + "60" }}>
              <AlertTriangle size={11} className="mt-0.5 shrink-0" />
              This file is attached for your reference, but we can't automatically read CAD geometry in-browser yet. Enter wall length manually below.
            </div>
          )}

          {ocrStatus === "error" && (
            <div className="text-[11px] mb-3 flex items-start gap-1.5" style={{ color: COLORS.orange }}>
              <AlertTriangle size={11} className="mt-0.5 shrink-0" /> {ocrError}
            </div>
          )}

          {ocrStatus === "idle" && (
            <div className="text-[10px] mb-4 flex items-start gap-1.5" style={{ color: COLORS.ink + "60" }}>
              <AlertTriangle size={11} className="mt-0.5 shrink-0" />
              We auto-scan photos and PDFs for dimension text (e.g. 12'-6", 3.6m). It's not perfect — always double-check the number below against your sketch.
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 mb-3">
            <div className="col-span-2">
              <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>
                Total wall length (running ft) — sum of all wall lines on your sketch
              </label>
              <input
                value={wallLength} onChange={(e) => setWallLength(e.target.value.replace(/[^0-9.]/g, ""))}
                placeholder="e.g. 180"
                inputMode="decimal"
                className="mono w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2"
                style={{ "--tw-ring-color": COLORS.orange }}
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>Wall height (ft)</label>
              <input
                value={wallHeight} onChange={(e) => setWallHeight(e.target.value.replace(/[^0-9.]/g, ""))}
                inputMode="decimal"
                className="mono w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2"
                style={{ "--tw-ring-color": COLORS.orange }}
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>Wall thickness</label>
              <select
                value={thickness} onChange={(e) => setThickness(e.target.value)}
                className="w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2"
                style={{ "--tw-ring-color": COLORS.orange }}
              >
                <option value="4.5">4.5" (partition wall)</option>
                <option value="9">9" (load-bearing wall)</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>
                Doors/windows deduction (%)
              </label>
              <input
                value={openingsPct} onChange={(e) => setOpeningsPct(e.target.value.replace(/[^0-9.]/g, ""))}
                inputMode="decimal"
                className="mono w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2"
                style={{ "--tw-ring-color": COLORS.orange }}
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>Wastage buffer (%)</label>
              <input
                value={wastagePct} onChange={(e) => setWastagePct(e.target.value.replace(/[^0-9.]/g, ""))}
                inputMode="decimal"
                className="mono w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2"
                style={{ "--tw-ring-color": COLORS.orange }}
              />
            </div>
          </div>

          <button
            onClick={calculate}
            disabled={!wallLength || !wallHeight}
            style={{ background: wallLength && wallHeight ? COLORS.orange : COLORS.ink + "30" }}
            className="w-full text-white rounded-lg py-2.5 font-bold text-sm flex items-center justify-center gap-2 mb-3"
          >
            <Ruler size={15} /> Calculate bricks required
          </button>

          {result && (
            <div className="rounded-md p-3" style={{ background: COLORS.concrete }}>
              <div className="space-y-1 mb-3">
                <Row label="Wall volume (L × H × T)" value={`${result.grossVolume.toFixed(1)} cu.ft`} />
                <Row label={`− Openings (${openingsPct}%)`} value={`${result.netVolume.toFixed(1)} cu.ft net`} />
                <Row label={`× ${BRICKS_PER_CUFT} bricks/cu.ft`} value={`${Math.round(result.baseBricks).toLocaleString()} bricks`} />
                <Row label={`+ Wastage buffer (${wastagePct}%)`} value="" />
                <div className="h-px bg-black/10 my-1" />
                <Row label="Estimated bricks required" value={`${result.totalBricks.toLocaleString()} pcs`} bold />
              </div>

              {brickProducts.length > 0 && (
                <>
                  <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>Add to cart as</label>
                  <select
                    value={selectedProductId} onChange={(e) => setSelectedProductId(e.target.value)}
                    className="w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2 mb-2 bg-white"
                    style={{ "--tw-ring-color": COLORS.orange }}
                  >
                    {brickProducts.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                  <button
                    onClick={addEstimateToCart}
                    style={{ background: added ? COLORS.steel : COLORS.orange }}
                    className="w-full text-white rounded-lg py-2.5 font-bold text-sm flex items-center justify-center gap-2"
                  >
                    {added ? <Check size={15} /> : <ShoppingCart size={15} />}
                    {added
                      ? "Added to cart"
                      : `Add ~${Math.ceil(result.totalBricks / 1000).toLocaleString()},000 bricks to cart (best price)`}
                  </button>
                </>
              )}

              <div className="text-[10px] mt-2" style={{ color: COLORS.ink + "60" }}>
                Estimate only, based on a standard {BRICKS_PER_CUFT} bricks/cu.ft rule of thumb for modular brick with mortar joints. Always confirm quantities with your engineer or contractor before ordering.
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

const ProductCard = memo(function ProductCard({ product, vendors, cart, addToCart, reviews }) {
  const cat = catById(product.cat);
  const offers = [...product.offers].sort((a, b) => {
    const aOut = a.stock <= 0, bOut = b.stock <= 0;
    if (aOut !== bOut) return aOut ? 1 : -1; // out-of-stock sinks to the bottom regardless of price
    return a.price - b.price;
  });
  const inStockOffers = offers.filter((o) => o.stock > 0);
  const lowestPrice = inStockOffers[0]?.price ?? offers[0]?.price;
  const prodRating = productRating(product.id, reviews);
  if (!offers.length) return null;

  return (
    <div className="bg-white rounded-lg overflow-hidden border border-black/5">
      <div className="px-4 pt-3.5 pb-2.5 flex items-start justify-between">
        <div>
          <div className="disp text-lg font-700 leading-tight" style={{ color: COLORS.ink }}>{product.name}</div>
          <div className="text-[11px] mt-0.5 flex items-center gap-1.5 flex-wrap" style={{ color: COLORS.ink + "70" }}>
            <span>{cat.unit} &middot; HSN {cat.hsn} &middot; GST {cat.hasGstScheme ? `${cat.gstCompositionRate}–${cat.gst}%*` : `${cat.gst}%`} &middot; {offers.length} vendor{offers.length > 1 ? "s" : ""}</span>
            {prodRating != null && (
              <span className="flex items-center gap-0.5 font-semibold" style={{ color: COLORS.steel }}>
                <Star size={10} fill={COLORS.steel} color={COLORS.steel} /> {prodRating.toFixed(1)} product rating
              </span>
            )}
          </div>
        </div>
        <div className="text-right shrink-0 pl-3">
          <div className="text-[10px] uppercase tracking-wide" style={{ color: COLORS.ink + "60" }}>from</div>
          <div className="mono font-bold text-lg" style={{ color: COLORS.orange }}>{fmt(lowestPrice)}</div>
        </div>
      </div>

      <div className="border-t border-black/5">
        {offers.map((o, i) => {
          const vendor = vendorById(vendors, o.vendorId);
          const displayRating = liveVendorRating(vendor, reviews);
          const key = `${product.id}__${o.vendorId}`;
          const qty = cart[key] || 0;
          const status = stockStatus(o, cat);
          const isBest = status !== "out" && o === inStockOffers[0];
          const fresh = isFreshStock(o.updatedAt);
          return (
            <div key={o.vendorId} className="flex items-center justify-between px-4 py-2.5 border-b border-black/5 last:border-b-0"
              style={{ background: isBest ? COLORS.yellow + "20" : status === "out" ? COLORS.ink + "05" : "transparent", opacity: status === "out" ? 0.7 : 1 }}>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-sm font-semibold truncate" style={{ color: COLORS.ink }}>{vendor.name}</span>
                  {isBest && (
                    <span style={{ background: COLORS.yellow, color: COLORS.charcoal }} className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded flex items-center gap-0.5 shrink-0">
                      <TrendingDown size={9} /> Best rate
                    </span>
                  )}
                  {fresh && status !== "out" && (
                    <span style={{ background: COLORS.steel, color: "white" }} className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded flex items-center gap-0.5 shrink-0">
                      <Zap size={9} /> Fresh stock
                    </span>
                  )}
                  {status === "low" && (
                    <span style={{ background: COLORS.orange + "20", color: COLORS.orange }} className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded flex items-center gap-0.5 shrink-0">
                      <AlertTriangle size={9} /> Low stock
                    </span>
                  )}
                  {status === "out" && (
                    <span style={{ background: COLORS.ink + "15", color: COLORS.ink + "90" }} className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded shrink-0">
                      Out of stock
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2.5 mt-0.5 text-[11px]" style={{ color: COLORS.ink + "70" }}>
                  <span className="flex items-center gap-0.5"><Star size={10} fill={COLORS.steel} color={COLORS.steel} /> {displayRating.toFixed(1)}</span>
                  <span className="flex items-center gap-0.5"><Truck size={10} /> {vendor.deliveryDays}-day delivery</span>
                  <span className="flex items-center gap-0.5"><Clock size={10} /> updated {timeAgo(o.updatedAt)}</span>
                  {cat.hasGstScheme && (
                    <span className="mono font-semibold" style={{ color: o.gstScheme === "composition" ? COLORS.steel : COLORS.ink + "70" }}>
                      GST {effectiveGstPct(o, cat)}%{o.gstScheme === "composition" ? " (no ITC)" : " (ITC)"}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0 pl-2">
                <span className="mono font-bold text-sm" style={{ color: COLORS.ink }}>{fmt(o.price)}</span>
                {status === "out" ? (
                  <span className="text-xs font-bold px-3 py-1.5" style={{ color: COLORS.ink + "50" }}>Unavailable</span>
                ) : qty === 0 ? (
                  <button onClick={() => addToCart(product.id, o.vendorId, 1)} style={{ borderColor: COLORS.orange, color: COLORS.orange }} className="text-xs font-bold border-2 rounded-md px-3 py-1.5">
                    ADD
                  </button>
                ) : (
                  <div className="flex items-center gap-2 rounded-md" style={{ background: COLORS.orange }}>
                    <button onClick={() => addToCart(product.id, o.vendorId, -1)} className="text-white px-2 py-1.5"><Minus size={13} /></button>
                    <span className="text-white font-bold text-sm mono w-4 text-center">{qty}</span>
                    <button onClick={() => addToCart(product.id, o.vendorId, 1)} className="text-white px-2 py-1.5"><Plus size={13} /></button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
});

// ---------- Cart / Checkout ----------
function CartScreen({ lines, addToCart, subtotal, gstTotal, deliveryFee, grandTotal, payment, setPayment, gstin, setGstin, onBack, onPlaceOrder, location, onRequestLocation, onManualAddress, onSetGstChoice, buyerSession, savedAddresses, onSaveAddress, onSelectAddress, onDeleteAddress, t }) {
  const [payState, setPayState] = useState("idle"); // idle | processing | error
  const [payError, setPayError] = useState("");
  const [testMode, setTestMode] = useState(false);

  const selectedMethod = PAYMENT_METHODS.find((p) => p.id === payment);

  function handleCheckout() {
    if (!selectedMethod) return;
    setPayError("");

    if (!selectedMethod.gateway) {
      // Cash on Delivery — no gateway needed, book immediately.
      onPlaceOrder();
      return;
    }

    setPayState("processing");
    openRazorpayCheckout({
      amountRupees: testMode ? 1 : grandTotal,
      buyerMobile: buyerSession?.mobile,
      buyerName: buyerSession?.name,
      onSuccess: () => {
        setPayState("idle");
        onPlaceOrder();
      },
      onFailure: (msg) => {
        setPayState("error");
        setPayError(msg);
      },
      onDismiss: () => {
        setPayState((s) => (s === "processing" ? "idle" : s));
      },
    });
  }
  return (
    <div className="max-w-5xl mx-auto px-4 pb-40">
      <button onClick={onBack} className="flex items-center gap-1.5 py-4 text-sm font-semibold" style={{ color: COLORS.steel }}>
        <ArrowLeft size={15} /> Back to catalog
      </button>

      <div className="disp text-2xl font-800 mb-3" style={{ color: COLORS.ink }}>Delivery Challan &mdash; Review</div>

      {lines.length === 0 ? (
        <div className="bg-white rounded-lg p-10 text-center text-sm" style={{ color: COLORS.ink + "80" }}>
          Your cart is empty. Go add some materials.
        </div>
      ) : (
        <>
          <div className="bg-white rounded-lg border border-black/5 divide-y divide-black/5 mb-5">
            {lines.map((l) => {
              const base = l.offer.price * l.qty;
              const gstAmt = (base * l.gstPct) / 100;
              const lineTotal = base + gstAmt;
              return (
                <div key={l.key} className="px-4 py-3">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0">
                      <div className="font-semibold text-sm truncate" style={{ color: COLORS.ink }}>{l.product.name}</div>
                      <div className="text-[11px]" style={{ color: COLORS.ink + "70" }}>
                        {l.vendor.name} &middot; HSN {l.cat.hsn} &middot; {fmt(l.offer.price)} &times; {l.qty}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0 pl-3">
                      <div className="flex items-center gap-2 rounded-md" style={{ background: COLORS.charcoal }}>
                        <button onClick={() => addToCart(l.product.id, l.vendor.id, -1)} className="text-white px-2 py-1.5"><Minus size={12} /></button>
                        <span className="text-white font-bold text-xs mono w-4 text-center">{l.qty}</span>
                        <button onClick={() => addToCart(l.product.id, l.vendor.id, 1)} className="text-white px-2 py-1.5"><Plus size={12} /></button>
                      </div>
                      <span className="mono font-bold text-sm w-20 text-right" style={{ color: COLORS.ink }}>{fmt(lineTotal)}</span>
                    </div>
                  </div>

                  {l.cat.hasGstScheme && (
                    <div className="flex items-center gap-1.5 mt-2">
                      <span className="text-[10px] font-semibold" style={{ color: COLORS.ink + "70" }}>Need ITC on this?</span>
                      <button
                        onClick={() => onSetGstChoice(l.key, "itc")}
                        className="text-[10px] font-bold px-2 py-1 rounded-md border"
                        style={l.gstScheme === "itc"
                          ? { background: COLORS.orange, color: "white", borderColor: COLORS.orange }
                          : { background: "white", color: COLORS.ink + "70", borderColor: "rgba(0,0,0,0.1)" }}
                      >
                        Yes — {l.cat.gst}% with ITC
                      </button>
                      <button
                        onClick={() => onSetGstChoice(l.key, "composition")}
                        className="text-[10px] font-bold px-2 py-1 rounded-md border"
                        style={l.gstScheme === "composition"
                          ? { background: COLORS.steel, color: "white", borderColor: COLORS.steel }
                          : { background: "white", color: COLORS.ink + "70", borderColor: "rgba(0,0,0,0.1)" }}
                      >
                        No — {l.cat.gstCompositionRate}% only
                      </button>
                    </div>
                  )}

                  <div className="mono text-[10px] mt-1.5 flex items-center gap-2 flex-wrap" style={{ color: COLORS.ink + "60" }}>
                    <span>Base {fmt(base)}</span>
                    <span>+</span>
                    <span>GST {l.gstPct}%{l.cat.hasGstScheme ? (l.gstScheme === "composition" ? " (no ITC)" : " (ITC)") : ""} = {fmt(gstAmt)}</span>
                    <span>=</span>
                    <span className="font-bold" style={{ color: COLORS.ink + "90" }}>{fmt(lineTotal)}</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="bg-white rounded-lg border border-black/5 p-4 mb-5">
            <div className="disp text-sm font-700 uppercase tracking-wide mb-2" style={{ color: COLORS.steel }}>Delivery site</div>
            <LocationSection
              location={location} onRequestLocation={onRequestLocation} onManualAddress={onManualAddress} compact
              savedAddresses={savedAddresses} onSaveAddress={onSaveAddress} onSelectAddress={onSelectAddress} onDeleteAddress={onDeleteAddress}
              t={t}
            />
            <div className="mt-2 text-xs flex items-center gap-1.5" style={{ color: COLORS.ink + "70" }}>
              <Truck size={12} /> Estimated arrival in {Math.max(...lines.map((l) => l.vendor.deliveryDays))} day(s), pooled from {new Set(lines.map((l) => l.vendor.id)).size} vendor(s)
            </div>
          </div>

          <div className="bg-white rounded-lg border border-black/5 p-4 mb-5">
            <div className="disp text-sm font-700 uppercase tracking-wide mb-2" style={{ color: COLORS.steel }}>GST invoice (optional)</div>
            <label className="block text-xs mb-1" style={{ color: COLORS.ink + "80" }}>
              Enter your business GSTIN to get a tax invoice with input credit
            </label>
            <input
              value={gstin}
              onChange={(e) => setGstin(e.target.value.toUpperCase())}
              placeholder="e.g. 29AAAAA0000A1Z5"
              maxLength={15}
              className="mono w-full bg-concrete rounded-md px-3 py-2 text-sm outline-none border border-black/10 focus:ring-2 tracking-wider"
              style={{ background: COLORS.concrete, "--tw-ring-color": COLORS.orange }}
            />
          </div>

          <div className="disp text-sm font-700 uppercase tracking-wide mb-2" style={{ color: COLORS.steel }}>Payment method</div>
          <div className="grid grid-cols-2 gap-2.5 mb-5">
            {PAYMENT_METHODS.map((pm) => {
              const Icon = pm.icon;
              const active = payment === pm.id;
              return (
                <button key={pm.id} onClick={() => setPayment(pm.id)} className="rounded-lg p-3 text-left border-2 flex items-start gap-2.5 transition"
                  style={active ? { borderColor: COLORS.orange, background: COLORS.orange + "10" } : { borderColor: "rgba(0,0,0,0.08)", background: "white" }}>
                  <Icon size={18} style={{ color: active ? COLORS.orange : COLORS.ink }} className="mt-0.5" />
                  <div>
                    <div className="text-sm font-bold" style={{ color: COLORS.ink }}>{pm.label}</div>
                    <div className="text-[10px]" style={{ color: COLORS.ink + "70" }}>{pm.sub}</div>
                  </div>
                  {active && <Check size={14} className="ml-auto shrink-0" style={{ color: COLORS.orange }} />}
                </button>
              );
            })}
          </div>

          <div className="bg-white rounded-lg border border-black/5 p-4 space-y-1.5 mb-4">
            <Row label={t("subtotal")} value={fmt(subtotal)} />
            <Row label={`GST (as applicable per item)`} value={fmt(gstTotal)} />
            <Row label="Delivery & handling" value={fmt(deliveryFee)} />
            <div className="h-px bg-black/10 my-1.5" />
            <Row label={t("total_payable")} value={fmt(grandTotal)} bold />
          </div>

          {selectedMethod?.gateway && (
            <div className="rounded-lg p-3 mb-4 flex items-center justify-between" style={{ background: COLORS.steel + "10" }}>
              <div className="text-[11px]" style={{ color: COLORS.steel }}>
                <div className="font-bold">Developer: test the gateway with ₹1</div>
                <div style={{ color: COLORS.ink + "70" }}>Charges ₹1 instead of {fmt(grandTotal)} — for validating the payment flow only.</div>
              </div>
              <button
                onClick={() => setTestMode((t) => !t)}
                className="w-11 h-6 rounded-full shrink-0 relative transition"
                style={{ background: testMode ? COLORS.orange : COLORS.ink + "20" }}
              >
                <span className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all" style={{ left: testMode ? "22px" : "2px" }} />
              </button>
            </div>
          )}

          {payError && (
            <div className="rounded-lg p-3 mb-4 text-xs flex items-start gap-1.5" style={{ background: COLORS.orange + "10", color: COLORS.orange }}>
              <AlertTriangle size={13} className="mt-0.5 shrink-0" /> {payError}
            </div>
          )}
        </>
      )}

      {lines.length > 0 && (
        <button
          onClick={handleCheckout}
          disabled={!payment || payState === "processing"}
          style={{ background: payment && payState !== "processing" ? COLORS.orange : COLORS.ink + "30" }}
          className="fixed bottom-5 left-1/2 -translate-x-1/2 w-[calc(100%-2rem)] max-w-md text-white rounded-lg py-3.5 font-bold text-sm shadow-xl shadow-black/20"
        >
          {payState === "processing"
            ? "Opening payment gateway…"
            : !payment
            ? "Select a payment method"
            : selectedMethod?.gateway
            ? `Pay ${testMode ? fmt(1) + " (test)" : fmt(grandTotal)} via ${selectedMethod.label}`
            : `${t("confirm_book")} — ${fmt(grandTotal)}`}
        </button>
      )}
    </div>
  );
}

function Row({ label, value, bold }) {
  return (
    <div className="flex items-center justify-between">
      <span className={`text-sm ${bold ? "font-bold" : ""}`} style={{ color: COLORS.ink }}>{label}</span>
      <span className={`mono text-sm ${bold ? "font-bold text-base" : ""}`} style={{ color: bold ? COLORS.orange : COLORS.ink }}>{value}</span>
    </div>
  );
}

// ---------- Confirmation (Tax Invoice style) ----------
function ConfirmScreen({ order, onDone, onTrack }) {
  const cgst = order.gstTotal / 2;
  const sgst = order.gstTotal / 2;
  return (
    <div className="max-w-md mx-auto px-4 pt-10 pb-10">
      <div className="text-center mb-6">
        <div style={{ background: COLORS.yellow }} className="w-16 h-16 rounded-full mx-auto flex items-center justify-center mb-4">
          <Check size={28} style={{ color: COLORS.charcoal }} />
        </div>
        <div className="disp text-2xl font-800 mb-1" style={{ color: COLORS.ink }}>Order booked</div>
        <div className="text-sm" style={{ color: COLORS.ink + "80" }}>
          Order <span className="mono font-bold">{order.id}</span> confirmed, pooled from {new Set(order.lines.map((l) => l.vendor.id)).size} vendor(s).
        </div>
      </div>

      <div className="bg-white rounded-lg border border-black/5 p-4 mb-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5 disp text-sm font-700 uppercase tracking-wide" style={{ color: COLORS.steel }}>
            <FileText size={14} /> Tax invoice
          </div>
          <span className="mono text-xs font-bold" style={{ color: COLORS.ink }}>{order.invoiceNo}</span>
        </div>

        {order.buyerGstin && (
          <div className="text-xs mb-2" style={{ color: COLORS.ink + "80" }}>
            Buyer GSTIN: <span className="mono font-semibold">{order.buyerGstin}</span>
          </div>
        )}

        {order.lines.map((l) => {
          const base = l.offer.price * l.qty;
          const gstAmt = (base * l.gstPct) / 100;
          return (
            <div key={l.key} className="py-1.5 border-b border-black/5 last:border-b-0">
              <div className="flex justify-between text-sm">
                <span style={{ color: COLORS.ink }}>{l.product.name} &times; {l.qty}</span>
                <span className="mono font-semibold" style={{ color: COLORS.ink }}>{fmt(base + gstAmt)}</span>
              </div>
              <div className="text-[10px]" style={{ color: COLORS.ink + "60" }}>
                HSN {l.cat.hsn} &middot; sold by {l.vendor.name} (GSTIN {l.vendor.gstin})
              </div>
              <div className="mono text-[10px] mt-0.5" style={{ color: COLORS.ink + "60" }}>
                Base {fmt(base)} + GST {l.gstPct}%{l.cat.hasGstScheme ? (l.gstScheme === "composition" ? " composition, no ITC" : " with ITC") : ""} ({fmt(gstAmt)})
              </div>
            </div>
          );
        })}

        <div className="mt-2 space-y-1">
          <Row label="Taxable value" value={fmt(order.subtotal)} />
          <Row label="CGST" value={fmt(cgst)} />
          <Row label="SGST" value={fmt(sgst)} />
          <Row label="Delivery & handling" value={fmt(order.deliveryFee)} />
          <div className="h-px bg-black/10 my-1.5" />
          <Row label={`Total paid via ${PAYMENT_METHODS.find((p) => p.id === order.payment)?.label}`} value={fmt(order.total)} bold />
        </div>

        <div className="flex items-center gap-1.5 mt-3 text-xs" style={{ color: COLORS.steel }}>
          <Truck size={13} /> Expected delivery in {order.etaDays} day(s)
        </div>
      </div>

      <div className="flex gap-2.5">
        <button onClick={onTrack} style={{ background: COLORS.orange }} className="flex-1 text-white rounded-lg py-3 font-bold text-sm">
          Track delivery
        </button>
        <button onClick={onDone} style={{ background: COLORS.charcoal }} className="flex-1 text-white rounded-lg py-3 font-bold text-sm">
          Back to catalog
        </button>
      </div>
    </div>
  );
}

// ---------- Orders / Tracking ----------
// ---------- Delivery partner live tracking map ----------
function DeliveryTrackingMap({ originLat, originLng, destLat, destLng, destLabel, progress }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const truckMarkerRef = useRef(null);
  const [mapError, setMapError] = useState(false);

  // Initialize the map once per route (origin/destination pair)
  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const L = (await import("leaflet")).default;
        if (cancelled || !containerRef.current || mapRef.current) return;

        const map = L.map(containerRef.current, { zoomControl: false, attributionControl: true, scrollWheelZoom: false });
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: "&copy; OpenStreetMap contributors",
        }).addTo(map);

        const bounds = L.latLngBounds([[originLat, originLng], [destLat, destLng]]);
        map.fitBounds(bounds, { padding: [30, 30] });

        const dotIcon = (color) =>
          L.divIcon({
            className: "",
            html: `<div style="width:12px;height:12px;border-radius:50%;background:${color};border:2px solid white;box-shadow:0 0 0 1px rgba(0,0,0,0.2)"></div>`,
            iconSize: [12, 12],
            iconAnchor: [6, 6],
          });
        const truckIcon = L.divIcon({
          className: "",
          html: `<div style="font-size:20px;line-height:1;transform:translate(-2px,-2px);">🚚</div>`,
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        });

        L.marker([originLat, originLng], { icon: dotIcon("#3D5A73") }).addTo(map).bindPopup("Vendor / dispatch point");
        L.marker([destLat, destLng], { icon: dotIcon("#20241F") }).addTo(map).bindPopup(destLabel);
        L.polyline([[originLat, originLng], [destLat, destLng]], { color: "#E1611F", weight: 3, dashArray: "6,6" }).addTo(map);

        const curLat = originLat + (destLat - originLat) * progress;
        const curLng = originLng + (destLng - originLng) * progress;
        truckMarkerRef.current = L.marker([curLat, curLng], { icon: truckIcon }).addTo(map);

        mapRef.current = map;
      } catch (err) {
        setMapError(true);
      }
    })();

    return () => {
      cancelled = true;
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
        truckMarkerRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [originLat, originLng, destLat, destLng]);

  // Move the rider marker when progress changes, without rebuilding the whole map
  useEffect(() => {
    if (!truckMarkerRef.current) return;
    const curLat = originLat + (destLat - originLat) * progress;
    const curLng = originLng + (destLng - originLng) * progress;
    truckMarkerRef.current.setLatLng([curLat, curLng]);
  }, [progress, originLat, originLng, destLat, destLng]);

  if (mapError) {
    return (
      <div className="rounded-lg p-4 text-xs text-center" style={{ background: COLORS.concrete, color: COLORS.ink + "70" }}>
        Couldn't load the live map right now. The rider is still on the way — check back shortly.
      </div>
    );
  }

  return <div ref={containerRef} style={{ height: 200, borderRadius: 10, overflow: "hidden", background: COLORS.concrete }} />;
}

// ---------- Invoice PDF generation (real client-side PDF via jsPDF) ----------
// jsPDF's built-in fonts don't include the ₹ glyph, so PDFs use "Rs." instead.
const fmtPdf = (n) => "Rs. " + n.toLocaleString("en-IN", { maximumFractionDigits: 2 });

async function generateInvoicePdfBlob(order, buyerSession) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 40;
  let y = 50;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text("BuildKart", margin, y);
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text("Tax Invoice", pageWidth - margin, y, { align: "right" });
  y += 18;
  doc.setDrawColor(220);
  doc.line(margin, y, pageWidth - margin, y);
  y += 22;

  doc.setFontSize(10);
  doc.text(`Invoice No: ${order.invoiceNo}`, margin, y);
  doc.text(`Date: ${new Date(order.date).toLocaleDateString("en-IN")}`, pageWidth - margin, y, { align: "right" });
  y += 16;
  doc.text(`Order ID: ${order.id}`, margin, y);
  y += 16;
  if (buyerSession) {
    doc.text(`Billed to: ${buyerSession.name || "Guest"} (${buyerSession.mobile})`, margin, y);
    y += 16;
  }
  if (order.buyerGstin) {
    doc.text(`Buyer GSTIN: ${order.buyerGstin}`, margin, y);
    y += 16;
  }
  if (order.destLabel) {
    doc.text(`Delivered to: ${order.destLabel}`, margin, y);
    y += 16;
  }
  y += 8;

  doc.setFont("helvetica", "bold");
  doc.text("Item", margin, y);
  doc.text("Qty", 300, y);
  doc.text("Rate", 360, y);
  doc.text("GST", 430, y);
  doc.text("Amount", pageWidth - margin, y, { align: "right" });
  y += 6;
  doc.setDrawColor(220);
  doc.line(margin, y, pageWidth - margin, y);
  y += 16;
  doc.setFont("helvetica", "normal");

  order.lines.forEach((l) => {
    const base = l.offer.price * l.qty;
    const gstAmt = (base * l.gstPct) / 100;
    const lineTotal = base + gstAmt;
    doc.text(l.product.name.slice(0, 32), margin, y);
    doc.text(String(l.qty), 300, y);
    doc.text(l.offer.price.toLocaleString("en-IN"), 360, y);
    doc.text(`${l.gstPct}%`, 430, y);
    doc.text(lineTotal.toLocaleString("en-IN", { maximumFractionDigits: 0 }), pageWidth - margin, y, { align: "right" });
    y += 15;
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text(`HSN ${l.cat.hsn} — sold by ${l.vendor.name}`, margin, y);
    doc.setFontSize(10);
    doc.setTextColor(0);
    y += 16;
  });

  y += 6;
  doc.line(margin, y, pageWidth - margin, y);
  y += 20;

  const cgst = order.gstTotal / 2;
  const sgst = order.gstTotal / 2;
  const rows = [
    ["Taxable value", fmtPdf(order.subtotal)],
    ["CGST", fmtPdf(cgst)],
    ["SGST", fmtPdf(sgst)],
    ["Delivery & handling", fmtPdf(order.deliveryFee)],
  ];
  rows.forEach(([label, value]) => {
    doc.text(label, 400, y);
    doc.text(value, pageWidth - margin, y, { align: "right" });
    y += 16;
  });
  doc.setFont("helvetica", "bold");
  doc.text("Total Paid", 400, y);
  doc.text(fmtPdf(order.total), pageWidth - margin, y, { align: "right" });
  y += 30;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(130);
  doc.text("This is a system-generated invoice from BuildKart.", margin, y);

  return doc.output("blob");
}

// ---------- Bill sharing: native share sheet (WhatsApp/Mail/etc.) + fallbacks ----------
function BillShareCard({ order, buyerSession }) {
  const [busy, setBusy] = useState(false);
  const [shareError, setShareError] = useState("");

  async function handleDownload() {
    setBusy(true);
    try {
      const blob = await generateInvoicePdfBlob(order, buyerSession);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `BuildKart-Invoice-${order.invoiceNo}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch {
      setShareError("Couldn't generate the PDF right now.");
    }
    setBusy(false);
  }

  async function handleShare() {
    setBusy(true);
    setShareError("");
    try {
      const blob = await generateInvoicePdfBlob(order, buyerSession);
      const file = new File([blob], `BuildKart-Invoice-${order.invoiceNo}.pdf`, { type: "application/pdf" });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: `BuildKart Invoice ${order.invoiceNo}`,
          text: `Your BuildKart bill for order ${order.id} — total ${fmt(order.total)}.`,
        });
      } else {
        setShareError("Direct file sharing isn't supported on this browser. Use Download, then attach it manually in WhatsApp/Mail.");
      }
    } catch (err) {
      if (err?.name !== "AbortError") setShareError("Couldn't open the share sheet. Try Download instead.");
    }
    setBusy(false);
  }

  const waNumber = buyerSession?.mobile ? `91${buyerSession.mobile}` : "";
  const waText = encodeURIComponent(
    `Your BuildKart bill for order ${order.id} (Invoice ${order.invoiceNo}) — total ${fmt(order.total)}. I've downloaded the PDF — attaching it here.`
  );
  const mailSubject = encodeURIComponent(`BuildKart Invoice ${order.invoiceNo}`);
  const mailBody = encodeURIComponent(
    `Hi,\n\nYour BuildKart bill for order ${order.id} — total ${fmt(order.total)}.\nThe PDF has been downloaded to your device — please attach it to this email before sending.\n\nThanks,\nBuildKart`
  );

  return (
    <div className="mt-3 pt-3 border-t border-black/5">
      <div className="text-xs font-bold mb-2 flex items-center gap-1.5" style={{ color: COLORS.ink }}>
        <FileText size={13} style={{ color: COLORS.orange }} /> Share your bill
      </div>
      <div className="flex flex-wrap gap-2 mb-2">
        <button
          onClick={handleShare}
          disabled={busy}
          style={{ background: COLORS.orange }}
          className="text-white text-xs font-bold rounded-md px-3 py-2 flex items-center gap-1.5 disabled:opacity-60"
        >
          <Zap size={13} /> {busy ? "Preparing…" : "Share PDF (WhatsApp / Mail / etc.)"}
        </button>
        <button
          onClick={handleDownload}
          disabled={busy}
          className="text-xs font-bold rounded-md px-3 py-2 border disabled:opacity-60"
          style={{ borderColor: COLORS.ink + "20", color: COLORS.ink + "80" }}
        >
          Download PDF
        </button>
      </div>
      {shareError && <div className="text-[11px] mb-2" style={{ color: COLORS.orange }}>{shareError}</div>}
      <div className="flex flex-wrap gap-3 text-[11px]">
        {waNumber && (
          <a href={`https://wa.me/${waNumber}?text=${waText}`} target="_blank" rel="noreferrer" className="font-semibold underline" style={{ color: COLORS.steel }}>
            Open WhatsApp to your number
          </a>
        )}
        {buyerSession?.email && (
          <a href={`mailto:${buyerSession.email}?subject=${mailSubject}&body=${mailBody}`} className="font-semibold underline" style={{ color: COLORS.steel }}>
            Open email draft
          </a>
        )}
      </div>
      <div className="text-[10px] mt-2" style={{ color: COLORS.ink + "60" }}>
        "Share PDF" opens your device's real share sheet with the actual invoice attached — pick WhatsApp or Mail there to send it. The WhatsApp/email links above only pre-fill a message; browsers can't auto-attach a file to a specific contact without you confirming it yourself, so download first if you use those.
      </div>
    </div>
  );
}

function OrdersScreen({ orders, onAdvance, onBack, buyerSession, onReorder, onCancel, onSubmitReview, onRaiseDispute, reviews }) {
  return (
    <div className="max-w-5xl mx-auto px-4 pb-16">
      <button onClick={onBack} className="flex items-center gap-1.5 py-4 text-sm font-semibold" style={{ color: COLORS.steel }}>
        <ArrowLeft size={15} /> Back to catalog
      </button>
      <div className="disp text-2xl font-800 mb-4" style={{ color: COLORS.ink }}>My orders & tracking</div>

      {orders.length === 0 ? (
        <div className="bg-white rounded-lg p-10 text-center text-sm" style={{ color: COLORS.ink + "80" }}>
          No orders yet. Place one from the catalog to see live tracking here.
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((o) => (
            <div key={o.id} className="bg-white rounded-lg border border-black/5 p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="font-bold text-sm" style={{ color: COLORS.ink }}>Order {o.id}</div>
                  <div className="text-[11px]" style={{ color: COLORS.ink + "70" }}>
                    {o.date.toLocaleDateString("en-IN")} &middot; {o.lines.length} item line(s) &middot; {fmt(o.total)}
                  </div>
                </div>
                <span className="text-[10px] font-bold uppercase px-2 py-1 rounded" style={{ background: o.status === "cancelled" ? COLORS.ink + "15" : COLORS.orange + "15", color: o.status === "cancelled" ? COLORS.ink + "80" : COLORS.orange }}>
                  {o.status === "cancelled" ? "Cancelled" : TRACK_STAGES[o.stage]}
                </span>
              </div>

              {o.status === "cancelled" ? (
                <div className="rounded-md p-3 text-xs flex items-center gap-1.5" style={{ background: COLORS.steel + "10", color: COLORS.steel }}>
                  <Check size={13} /> {o.refundStatus === "refunded" ? `Refunded ${fmt(o.total)} to your original payment method.` : "Cancellation in progress."}
                </div>
              ) : (
                <>
                  <div className="flex items-center mb-1">
                    {TRACK_STAGES.map((stage, i) => (
                      <div key={stage} className="flex items-center flex-1 last:flex-none">
                        <div className="flex flex-col items-center">
                          <div
                            className="w-6 h-6 rounded-full flex items-center justify-center shrink-0"
                            style={{ background: i <= o.stage ? COLORS.orange : COLORS.ink + "15" }}
                          >
                            {i < o.stage ? (
                              <Check size={12} color="white" />
                            ) : i === o.stage ? (
                              <CircleDot size={12} color="white" />
                            ) : (
                              <span className="text-[10px] font-bold" style={{ color: COLORS.ink + "60" }}>{i + 1}</span>
                            )}
                          </div>
                          <span className="text-[9px] mt-1 text-center w-16 leading-tight" style={{ color: i <= o.stage ? COLORS.ink : COLORS.ink + "50" }}>
                            {stage}
                          </span>
                        </div>
                        {i < TRACK_STAGES.length - 1 && (
                          <div className="flex-1 h-0.5 mx-1 -mt-4" style={{ background: i < o.stage ? COLORS.orange : COLORS.ink + "15" }} />
                        )}
                      </div>
                    ))}
                  </div>

                  {o.stage >= 1 && o.originLat != null && o.destLat != null && (
                    <div className="mt-3 pt-3 border-t border-black/5">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div style={{ background: COLORS.steel + "18" }} className="w-8 h-8 rounded-full flex items-center justify-center">
                            <Truck size={15} style={{ color: COLORS.steel }} />
                          </div>
                          <div>
                            <div className="text-xs font-bold" style={{ color: COLORS.ink }}>{o.deliveryPartner.name}</div>
                            <div className="text-[10px]" style={{ color: COLORS.ink + "70" }}>{o.deliveryPartner.vehicle}</div>
                          </div>
                        </div>
                        <a
                          href={`tel:${o.deliveryPartner.phone.replace(/\s/g, "")}`}
                          className="text-[10px] font-bold px-2.5 py-1.5 rounded-md"
                          style={{ background: COLORS.orange, color: "white" }}
                        >
                          Call rider
                        </a>
                      </div>
                      <DeliveryTrackingMap
                        originLat={o.originLat} originLng={o.originLng}
                        destLat={o.destLat} destLng={o.destLng}
                        destLabel={o.destLabel || "Delivery site"}
                        progress={STAGE_PROGRESS[o.stage]}
                      />
                      <div className="text-[10px] mt-2" style={{ color: COLORS.ink + "60" }}>
                        Simulated live location — moves as the order stage advances. A production version would plot the rider's real GPS from a delivery-partner app.
                      </div>
                    </div>
                  )}

                  {o.stage < TRACK_STAGES.length - 1 && (
                    <button
                      onClick={() => onAdvance(o.id)}
                      className="mt-3 text-xs font-bold border-2 rounded-md px-3 py-1.5"
                      style={{ borderColor: COLORS.steel, color: COLORS.steel }}
                    >
                      Simulate next update →
                    </button>
                  )}
                  {o.stage === TRACK_STAGES.length - 1 && (
                    <>
                      <div className="mt-3 text-xs font-semibold flex items-center gap-1" style={{ color: COLORS.orange }}>
                        <Check size={13} /> Delivered to site
                      </div>
                      <BillShareCard order={o} buyerSession={buyerSession} />
                      <ReviewAndDisputeCard order={o} reviews={reviews} onSubmitReview={onSubmitReview} onRaiseDispute={onRaiseDispute} />
                    </>
                  )}
                </>
              )}

              <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-black/5">
                <button
                  onClick={() => onReorder(o)}
                  className="text-xs font-bold border-2 rounded-md px-3 py-1.5 flex items-center gap-1.5"
                  style={{ borderColor: COLORS.orange, color: COLORS.orange }}
                >
                  <RefreshCw size={12} /> Reorder
                </button>
                {o.status !== "cancelled" && o.stage < 2 && (
                  <button
                    onClick={() => onCancel(o.id)}
                    className="text-xs font-bold px-3 py-1.5"
                    style={{ color: COLORS.ink + "60" }}
                  >
                    Cancel order (auto-refund)
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-5 text-xs px-1" style={{ color: COLORS.ink + "60" }}>
        In production this stage would update automatically from the vendor's dispatch and the delivery driver's live GPS, instead of the manual button above.
      </div>
    </div>
  );
}

// ---------- Post-delivery reviews & dispute/refund ----------
function ReviewAndDisputeCard({ order, reviews, onSubmitReview, onRaiseDispute }) {
  const [ratings, setRatings] = useState({});
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [disputeOpen, setDisputeOpen] = useState(false);
  const [disputeReason, setDisputeReason] = useState("");
  const [disputeSubmitted, setDisputeSubmitted] = useState(false);

  const vendorIds = [...new Set(order.lines.map((l) => l.vendor.id))];
  const alreadyReviewed = reviews.some((r) => r.orderId === order.id);
  const hasDisputeAlready = order.refundStatus === "dispute_open" || order.refundStatus === "refunded" || order.refundStatus === "dispute_rejected";

  function submit() {
    vendorIds.forEach((vendorId) => {
      const rating = ratings[vendorId] || 5;
      onSubmitReview(order.id, "vendor", vendorId, rating, comment);
    });
    order.lines.forEach((l) => {
      const rating = ratings[l.product.id] || 5;
      onSubmitReview(order.id, "product", l.product.id, rating, "");
    });
    setSubmitted(true);
  }

  return (
    <div className="mt-3 pt-3 border-t border-black/5">
      {!alreadyReviewed && !submitted ? (
        <div>
          <div className="text-xs font-bold mb-2" style={{ color: COLORS.ink }}>Rate this order</div>
          {vendorIds.map((vendorId) => {
            const vendorName = order.lines.find((l) => l.vendor.id === vendorId)?.vendor.name;
            return (
              <div key={vendorId} className="flex items-center justify-between mb-1.5">
                <span className="text-xs" style={{ color: COLORS.ink + "80" }}>{vendorName}</span>
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button key={n} onClick={() => setRatings((r) => ({ ...r, [vendorId]: n }))}>
                      <Star size={16} fill={(ratings[vendorId] || 0) >= n ? COLORS.yellow : "none"} color={COLORS.yellow} />
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
          <textarea
            value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Any comments? (optional)"
            className="w-full border border-black/10 rounded-md px-3 py-2 text-xs outline-none focus:ring-2 mt-1 mb-2"
            style={{ "--tw-ring-color": COLORS.orange }} rows={2}
          />
          <button onClick={submit} style={{ background: COLORS.orange }} className="text-white text-xs font-bold rounded-md px-3 py-2">
            Submit rating
          </button>
        </div>
      ) : (
        <div className="text-xs flex items-center gap-1.5" style={{ color: COLORS.steel }}>
          <Check size={13} /> Thanks for rating this order!
        </div>
      )}

      <div className="mt-3 pt-3 border-t border-black/5">
        {hasDisputeAlready ? (
          <div className="text-xs" style={{ color: COLORS.ink + "70" }}>
            {order.refundStatus === "dispute_open" && "Dispute submitted — our team is reviewing it."}
            {order.refundStatus === "refunded" && `Refund approved — ${fmt(order.total)} refunded.`}
            {order.refundStatus === "dispute_rejected" && "Your dispute was reviewed and not approved for refund."}
          </div>
        ) : !disputeOpen ? (
          <button onClick={() => setDisputeOpen(true)} className="text-[11px] font-semibold underline" style={{ color: COLORS.ink + "60" }}>
            Report an issue with this order
          </button>
        ) : !disputeSubmitted ? (
          <div>
            <label className="block text-[10px] font-semibold mb-1" style={{ color: COLORS.ink + "70" }}>What went wrong?</label>
            <textarea
              value={disputeReason} onChange={(e) => setDisputeReason(e.target.value)}
              placeholder="e.g. Wrong quantity delivered, damaged materials..."
              className="w-full border border-black/10 rounded-md px-3 py-2 text-xs outline-none focus:ring-2 mb-2"
              style={{ "--tw-ring-color": COLORS.orange }} rows={2}
            />
            <button
              onClick={() => { if (disputeReason.trim()) { onRaiseDispute(order.id, disputeReason.trim()); setDisputeSubmitted(true); } }}
              style={{ background: COLORS.orange }}
              className="text-white text-xs font-bold rounded-md px-3 py-2"
            >
              Submit for review
            </button>
          </div>
        ) : (
          <div className="text-xs flex items-center gap-1.5" style={{ color: COLORS.steel }}>
            <Check size={13} /> Submitted — our team will review and get back to you.
          </div>
        )}
      </div>
    </div>
  );
}

// ---------- Buyer auto-login (mobile + OTP) ----------
function BuyerLogin({ onLogin, t }) {
  const tr = t || ((k) => TRANSLATIONS[k]?.en || k);
  const [step, setStep] = useState("form"); // form | otp
  const [mobile, setMobile] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [touched, setTouched] = useState(false);

  const [otpSent, setOtpSent] = useState("");
  const [otpEntry, setOtpEntry] = useState("");
  const [otpError, setOtpError] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [cooldown, setCooldown] = useState(0);

  const mobileValid = MOBILE_REGEX.test(mobile);

  function sendOtp() {
    setTouched(true);
    if (!mobileValid) return;
    const code = String(Math.floor(1000 + Math.random() * 9000));
    setOtpSent(code);
    setOtpEntry("");
    setOtpError("");
    setStep("otp");
    setCooldown(30);
    const timer = setInterval(() => {
      setCooldown((c) => {
        if (c <= 1) { clearInterval(timer); return 0; }
        return c - 1;
      });
    }, 1000);
  }

  function verifyOtp() {
    if (otpEntry === otpSent) {
      onLogin({ mobile, name: name.trim() || "Guest", email: email.trim() || null });
      return;
    }
    setAttempts((a) => a + 1);
    setOtpError(attempts >= 2 ? "Still incorrect. Tap Resend to get a new code." : "That code doesn't match. Try again.");
  }

  return (
    <div className="max-w-md mx-auto px-4 pt-12 pb-16">
      <div className="text-center mb-6">
        <BrandMark size={48} />
        <div className="disp text-2xl font-800 mt-3" style={{ color: COLORS.ink }}>{tr("sign_in")}</div>
        <div className="text-sm mt-1" style={{ color: COLORS.ink + "80" }}>
          {step === "form"
            ? "Enter your mobile number to browse materials and place orders."
            : `Enter the 4-digit code we sent to ${mobile}.`}
        </div>
      </div>

      {step === "form" && (
        <div className="bg-white rounded-lg border border-black/5 p-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>Mobile number</label>
            <input
              value={mobile}
              onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
              placeholder="9876543210"
              inputMode="numeric"
              className="mono w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2 tracking-wide"
              style={{ "--tw-ring-color": COLORS.orange }}
            />
            {touched && !mobileValid && (
              <div className="text-[11px] mt-1" style={{ color: COLORS.orange }}>Enter a valid 10-digit Indian mobile number.</div>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>
              Name <span className="font-normal" style={{ color: COLORS.ink + "60" }}>(optional)</span>
            </label>
            <input
              value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Ranzith"
              className="w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2"
              style={{ "--tw-ring-color": COLORS.orange }}
            />
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>
              Email <span className="font-normal" style={{ color: COLORS.ink + "60" }}>(optional, so we can email your bills)</span>
            </label>
            <input
              value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" type="email"
              className="w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2"
              style={{ "--tw-ring-color": COLORS.orange }}
            />
          </div>

          <button
            onClick={sendOtp}
            style={{ background: COLORS.orange }}
            className="w-full text-white rounded-lg py-3 font-bold text-sm flex items-center justify-center gap-2"
          >
            <Zap size={15} /> {tr("send_otp")}
          </button>

          <div className="text-[11px] text-center" style={{ color: COLORS.ink + "60" }}>
            No password needed — we verify your mobile number with a one-time code.
          </div>
        </div>
      )}

      {step === "otp" && (
        <div className="bg-white rounded-lg border border-black/5 p-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>Enter 4-digit OTP</label>
            <input
              value={otpEntry}
              onChange={(e) => { setOtpEntry(e.target.value.replace(/\D/g, "").slice(0, 4)); setOtpError(""); }}
              placeholder="••••"
              inputMode="numeric"
              className="mono w-full border border-black/10 rounded-md px-3 py-3 text-2xl tracking-[0.5em] text-center outline-none focus:ring-2"
              style={{ "--tw-ring-color": COLORS.orange }}
            />
            {otpError && <div className="text-[11px] mt-1" style={{ color: COLORS.orange }}>{otpError}</div>}
          </div>

          <div className="rounded-md p-2.5 text-[11px]" style={{ background: COLORS.steel + "10", color: COLORS.steel }}>
            Demo mode — no SMS gateway connected yet, so your test code is <span className="mono font-bold">{otpSent}</span>. In production this would arrive by SMS instead.
          </div>

          <button
            onClick={verifyOtp}
            disabled={otpEntry.length !== 4}
            style={{ background: otpEntry.length === 4 ? COLORS.orange : COLORS.ink + "30" }}
            className="w-full text-white rounded-lg py-3 font-bold text-sm flex items-center justify-center gap-2"
          >
            <Check size={15} /> Verify & continue
          </button>

          <div className="flex items-center justify-between text-[11px]">
            <button onClick={() => setStep("form")} style={{ color: COLORS.ink + "70" }} className="font-semibold">
              &larr; Change number
            </button>
            <button
              onClick={sendOtp}
              disabled={cooldown > 0}
              style={{ color: cooldown > 0 ? COLORS.ink + "40" : COLORS.orange }}
              className="font-semibold"
            >
              {cooldown > 0 ? `Resend in ${cooldown}s` : "Resend OTP"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- Vendor auto-login (mobile + OTP, optional GST match) ----------
function VendorLogin({ onLogin }) {
  const [step, setStep] = useState("form"); // form | otp
  const [mobile, setMobile] = useState("");
  const [gstinInput, setGstinInput] = useState("");
  const [touched, setTouched] = useState(false);

  const [otpSent, setOtpSent] = useState("");
  const [otpEntry, setOtpEntry] = useState("");
  const [otpError, setOtpError] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [cooldown, setCooldown] = useState(0);

  const mobileValid = MOBILE_REGEX.test(mobile);
  const gstinValid = gstinInput.trim() === "" || GSTIN_REGEX.test(gstinInput.trim().toUpperCase());
  const canSubmit = mobileValid && gstinValid;

  function sendOtp() {
    setTouched(true);
    if (!canSubmit) return;
    const code = String(Math.floor(1000 + Math.random() * 9000));
    setOtpSent(code);
    setOtpEntry("");
    setOtpError("");
    setStep("otp");
    setCooldown(30);
    const timer = setInterval(() => {
      setCooldown((c) => {
        if (c <= 1) { clearInterval(timer); return 0; }
        return c - 1;
      });
    }, 1000);
  }

  function verifyOtp() {
    if (otpEntry === otpSent) {
      onLogin({ mobile, gstinInput });
      return;
    }
    setAttempts((a) => a + 1);
    setOtpError(attempts >= 2 ? "Still incorrect. Tap Resend to get a new code." : "That code doesn't match. Try again.");
  }

  return (
    <div className="max-w-md mx-auto px-4 pt-12 pb-16">
      <div className="text-center mb-6">
        <BrandMark size={48} />
        <div className="disp text-2xl font-800 mt-3" style={{ color: COLORS.ink }}>Vendor sign-in</div>
        <div className="text-sm mt-1" style={{ color: COLORS.ink + "80" }}>
          {step === "form"
            ? "Enter your mobile number to get started. If you have a GSTIN, add it and we'll match your verified business automatically."
            : `Enter the 4-digit code we sent to ${mobile}.`}
        </div>
      </div>

      {step === "form" && (
        <div className="bg-white rounded-lg border border-black/5 p-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>Mobile number</label>
            <input
              value={mobile}
              onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
              placeholder="9876543210"
              inputMode="numeric"
              className="mono w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2 tracking-wide"
              style={{ "--tw-ring-color": COLORS.orange }}
            />
            {touched && !mobileValid && (
              <div className="text-[11px] mt-1" style={{ color: COLORS.orange }}>Enter a valid 10-digit Indian mobile number.</div>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>
              GST number <span className="font-normal" style={{ color: COLORS.ink + "60" }}>(optional, if you have one)</span>
            </label>
            <input
              value={gstinInput}
              onChange={(e) => setGstinInput(e.target.value.toUpperCase().slice(0, 15))}
              placeholder="29ABCDE1234F1Z5"
              className="mono w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2 tracking-wider"
              style={{ "--tw-ring-color": COLORS.orange }}
            />
            {touched && !gstinValid && (
              <div className="text-[11px] mt-1" style={{ color: COLORS.orange }}>That doesn't look like a valid 15-character GSTIN.</div>
            )}
          </div>

          <button
            onClick={sendOtp}
            style={{ background: COLORS.orange }}
            className="w-full text-white rounded-lg py-3 font-bold text-sm flex items-center justify-center gap-2"
          >
            <Zap size={15} /> Send OTP
          </button>

          <div className="text-[11px] text-center" style={{ color: COLORS.ink + "60" }}>
            We verify your mobile number with a one-time code before letting you in — no password to remember.
          </div>
        </div>
      )}

      {step === "otp" && (
        <div className="bg-white rounded-lg border border-black/5 p-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>Enter 4-digit OTP</label>
            <input
              value={otpEntry}
              onChange={(e) => { setOtpEntry(e.target.value.replace(/\D/g, "").slice(0, 4)); setOtpError(""); }}
              placeholder="••••"
              inputMode="numeric"
              className="mono w-full border border-black/10 rounded-md px-3 py-3 text-2xl tracking-[0.5em] text-center outline-none focus:ring-2"
              style={{ "--tw-ring-color": COLORS.orange }}
            />
            {otpError && <div className="text-[11px] mt-1" style={{ color: COLORS.orange }}>{otpError}</div>}
          </div>

          {/* Demo-mode notice: no real SMS gateway is wired up yet, so the code is shown here for testing */}
          <div className="rounded-md p-2.5 text-[11px]" style={{ background: COLORS.steel + "10", color: COLORS.steel }}>
            Demo mode — no SMS gateway connected yet, so your test code is <span className="mono font-bold">{otpSent}</span>. In production this would arrive by SMS instead.
          </div>

          <button
            onClick={verifyOtp}
            disabled={otpEntry.length !== 4}
            style={{ background: otpEntry.length === 4 ? COLORS.orange : COLORS.ink + "30" }}
            className="w-full text-white rounded-lg py-3 font-bold text-sm flex items-center justify-center gap-2"
          >
            <Check size={15} /> Verify & continue
          </button>

          <div className="flex items-center justify-between text-[11px]">
            <button onClick={() => setStep("form")} style={{ color: COLORS.ink + "70" }} className="font-semibold">
              &larr; Change number
            </button>
            <button
              onClick={sendOtp}
              disabled={cooldown > 0}
              style={{ color: cooldown > 0 ? COLORS.ink + "40" : COLORS.orange }}
              className="font-semibold"
            >
              {cooldown > 0 ? `Resend in ${cooldown}s` : "Resend OTP"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- Subscription gate ----------
function SubscriptionScreen({ vendor, onSubscribe, onLogout }) {
  const [selected, setSelected] = useState("growth");
  const [paying, setPaying] = useState(false);

  function pay() {
    setPaying(true);
    // simulate a payment gateway round-trip
    setTimeout(() => {
      onSubscribe(selected);
      setPaying(false);
    }, 900);
  }

  return (
    <div className="max-w-md mx-auto px-4 pt-10 pb-16">
      <div className="text-center mb-6">
        <BrandMark size={48} />
        <div className="disp text-2xl font-800 mt-3" style={{ color: COLORS.ink }}>Choose your vendor plan</div>
        <div className="text-sm mt-1" style={{ color: COLORS.ink + "80" }}>
          A subscription is required to list products and sell on BuildKart, {vendor.name}.
        </div>
      </div>

      <div className="space-y-3 mb-5">
        {SUBSCRIPTION_PLANS.map((p) => {
          const active = selected === p.id;
          return (
            <button
              key={p.id}
              onClick={() => setSelected(p.id)}
              className="w-full text-left rounded-lg p-4 border-2 transition"
              style={active ? { borderColor: COLORS.orange, background: COLORS.orange + "08" } : { borderColor: "rgba(0,0,0,0.08)", background: "white" }}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="disp text-lg font-700" style={{ color: COLORS.ink }}>{p.name}</span>
                <span className="mono font-bold text-lg" style={{ color: COLORS.orange }}>
                  {fmt(p.price)}<span className="text-xs font-normal" style={{ color: COLORS.ink + "60" }}>/{p.cycle}</span>
                </span>
              </div>
              <ul className="space-y-1">
                {p.features.map((f) => (
                  <li key={f} className="text-xs flex items-center gap-1.5" style={{ color: COLORS.ink + "80" }}>
                    <Check size={12} style={{ color: COLORS.steel }} /> {f}
                  </li>
                ))}
              </ul>
            </button>
          );
        })}
      </div>

      <button
        onClick={pay}
        disabled={paying}
        style={{ background: COLORS.orange }}
        className="w-full text-white rounded-lg py-3 font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-70"
      >
        {paying ? "Processing payment…" : `Subscribe for ${fmt(planById(selected).price)}/${planById(selected).cycle}`}
      </button>
      <div className="text-[11px] text-center mt-2" style={{ color: COLORS.ink + "60" }}>
        Demo mode — no real payment gateway connected yet. In production this would run through Razorpay/Cashfree subscriptions.
      </div>

      <button onClick={onLogout} className="w-full text-center text-xs font-semibold mt-5" style={{ color: COLORS.ink + "60" }}>
        Log out
      </button>
    </div>
  );
}

// ---------- Bank account gate ----------
function BankAccountScreen({ vendor, onSave, onLogout }) {
  const [holderName, setHolderName] = useState(vendor.name || "");
  const [accountNumber, setAccountNumber] = useState("");
  const [confirmAccountNumber, setConfirmAccountNumber] = useState("");
  const [ifsc, setIfsc] = useState("");
  const [bankName, setBankName] = useState("");
  const [touched, setTouched] = useState(false);
  const [verifying, setVerifying] = useState(false);

  const accountValid = /^\d{9,18}$/.test(accountNumber);
  const accountsMatch = accountNumber === confirmAccountNumber;
  const ifscValid = IFSC_REGEX.test(ifsc.toUpperCase());
  const canSubmit = holderName.trim() && accountValid && accountsMatch && ifscValid && bankName.trim();

  function submit() {
    setTouched(true);
    if (!canSubmit) return;
    setVerifying(true);
    // simulate a penny-drop verification round-trip
    setTimeout(() => {
      onSave({ holderName: holderName.trim(), accountNumber, ifsc: ifsc.toUpperCase(), bankName: bankName.trim() });
      setVerifying(false);
    }, 1000);
  }

  return (
    <div className="max-w-md mx-auto px-4 pt-10 pb-16">
      <div className="text-center mb-6">
        <BrandMark size={48} />
        <div className="disp text-2xl font-800 mt-3" style={{ color: COLORS.ink }}>Add your payout bank account</div>
        <div className="text-sm mt-1" style={{ color: COLORS.ink + "80" }}>
          Buyer payments settle directly to this account after each order, minus BuildKart's {PLATFORM_COMMISSION_PCT}% platform fee.
        </div>
      </div>

      <div className="bg-white rounded-lg border border-black/5 p-4 space-y-3.5">
        <div>
          <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>Account holder name</label>
          <input value={holderName} onChange={(e) => setHolderName(e.target.value)}
            className="w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2" style={{ "--tw-ring-color": COLORS.orange }} />
        </div>

        <div>
          <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>Account number</label>
          <input value={accountNumber} onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, "").slice(0, 18))} inputMode="numeric"
            className="mono w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2 tracking-wide" style={{ "--tw-ring-color": COLORS.orange }} />
          {touched && !accountValid && <div className="text-[11px] mt-1" style={{ color: COLORS.orange }}>Enter a valid account number (9–18 digits).</div>}
        </div>

        <div>
          <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>Confirm account number</label>
          <input value={confirmAccountNumber} onChange={(e) => setConfirmAccountNumber(e.target.value.replace(/\D/g, "").slice(0, 18))} inputMode="numeric"
            className="mono w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2 tracking-wide" style={{ "--tw-ring-color": COLORS.orange }} />
          {touched && accountNumber && !accountsMatch && <div className="text-[11px] mt-1" style={{ color: COLORS.orange }}>Account numbers don't match.</div>}
        </div>

        <div>
          <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>IFSC code</label>
          <input value={ifsc} onChange={(e) => setIfsc(e.target.value.toUpperCase().slice(0, 11))} placeholder="HDFC0000034"
            className="mono w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2 tracking-wider" style={{ "--tw-ring-color": COLORS.orange }} />
          {touched && !ifscValid && <div className="text-[11px] mt-1" style={{ color: COLORS.orange }}>Enter a valid 11-character IFSC code.</div>}
        </div>

        <div>
          <label className="block text-xs font-semibold mb-1" style={{ color: COLORS.ink + "80" }}>Bank name</label>
          <input value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="e.g. HDFC Bank"
            className="w-full border border-black/10 rounded-md px-3 py-2.5 text-sm outline-none focus:ring-2" style={{ "--tw-ring-color": COLORS.orange }} />
        </div>

        <button
          onClick={submit}
          disabled={verifying}
          style={{ background: COLORS.orange }}
          className="w-full text-white rounded-lg py-3 font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-70"
        >
          {verifying ? "Verifying account…" : "Save & verify account"}
        </button>
        <div className="text-[11px] text-center" style={{ color: COLORS.ink + "60" }}>
          Demo mode — real verification would run a penny-drop check via a payout partner (e.g. Razorpay/Cashfree/Decentro) before enabling payouts.
        </div>
      </div>

      <button onClick={onLogout} className="w-full text-center text-xs font-semibold mt-5" style={{ color: COLORS.ink + "60" }}>
        Log out
      </button>
    </div>
  );
}

// ---------- Earnings & payouts summary ----------
function EarningsPanel({ vendor, payouts }) {
  const [expanded, setExpanded] = useState(false);
  const plan = planById(vendor.subscription.planId);
  const bank = vendor.bankAccount;
  const maskedAccount = bank ? "••••" + bank.accountNumber.slice(-4) : "—";

  const grossTotal = payouts.reduce((s, p) => s + p.gross, 0);
  const commissionTotal = payouts.reduce((s, p) => s + p.commission, 0);
  const totalNet = payouts.reduce((s, p) => s + p.net, 0);
  const netAfterSubscription = totalNet - plan.price;
  const isViable = netAfterSubscription >= 0;
  const ordersToBreakeven = totalNet > 0 && payouts.length > 0
    ? Math.ceil(plan.price / (totalNet / payouts.length))
    : null;

  const renewsInDays = Math.max(0, Math.ceil((new Date(vendor.subscription.renewsAt) - Date.now()) / (24 * 3600 * 1000)));

  return (
    <div className="bg-white rounded-lg border border-black/5 p-4 mb-5">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="disp text-sm font-700 uppercase tracking-wide" style={{ color: COLORS.steel }}>Earnings & payouts</div>
          <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded" style={{ background: COLORS.steel + "18", color: COLORS.steel }}>
            {plan.name} plan
          </span>
        </div>
        <button onClick={() => setExpanded((e) => !e)} className="text-[11px] font-semibold" style={{ color: COLORS.orange }}>
          {expanded ? "Hide details" : "View details"}
        </button>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-1">
        <div>
          <div className="mono font-bold text-lg" style={{ color: COLORS.orange }}>{fmt(totalNet)}</div>
          <div className="text-[10px] uppercase tracking-wide" style={{ color: COLORS.ink + "70" }}>Total credited</div>
        </div>
        <div>
          <div className="mono font-bold text-lg" style={{ color: COLORS.ink }}>{maskedAccount}</div>
          <div className="text-[10px] uppercase tracking-wide" style={{ color: COLORS.ink + "70" }}>{bank?.bankName || "No account"}</div>
        </div>
        <div>
          <div className="mono font-bold text-lg" style={{ color: COLORS.ink }}>{renewsInDays}d</div>
          <div className="text-[10px] uppercase tracking-wide" style={{ color: COLORS.ink + "70" }}>Until plan renews</div>
        </div>
      </div>

      {expanded && (
        <div className="mt-4 pt-4 border-t border-black/5">
          {/* Viability breakdown: is this vendor actually profitable after subscription cost? */}
          <div className="text-xs font-semibold mb-2 flex items-center gap-1.5" style={{ color: COLORS.ink + "80" }}>
            <TrendingDown size={12} className="rotate-180" style={{ color: COLORS.steel }} /> Profitability this cycle
          </div>
          <div className="rounded-md p-3 mb-4 space-y-1" style={{ background: COLORS.concrete }}>
            <Row label="Gross sales (from orders)" value={fmt(grossTotal)} />
            <Row label={`− Platform commission (${PLATFORM_COMMISSION_PCT}%)`} value={"− " + fmt(commissionTotal)} />
            <div className="h-px bg-black/10 my-1" />
            <Row label="= Net credited to your account" value={fmt(totalNet)} />
            <Row label={`− ${plan.name} plan subscription (/${plan.cycle})`} value={"− " + fmt(plan.price)} />
            <div className="h-px bg-black/10 my-1" />
            <Row
              label={isViable ? "= Net profit this cycle" : "= Net position this cycle"}
              value={(netAfterSubscription >= 0 ? "+" : "− ") + fmt(Math.abs(netAfterSubscription))}
              bold
            />
          </div>
          {!isViable && (
            <div className="rounded-md p-2.5 mb-4 text-[11px] flex items-start gap-1.5" style={{ background: COLORS.orange + "10", color: COLORS.orange }}>
              <AlertTriangle size={12} className="mt-0.5 shrink-0" />
              Your {plan.name} plan costs more than what you've earned so far this cycle
              {ordersToBreakeven ? ` — at your current average order size, about ${ordersToBreakeven} more order(s) would cover it.` : ". List more products or consider a lower-tier plan until sales pick up."}
            </div>
          )}

          <div className="text-xs font-semibold mb-2" style={{ color: COLORS.ink + "80" }}>Recent settlements</div>
          {payouts.length === 0 ? (
            <div className="text-xs" style={{ color: COLORS.ink + "60" }}>No orders settled yet — payouts will appear here as buyers order your products.</div>
          ) : (
            <div className="space-y-2">
              {payouts.slice(0, 6).map((p) => (
                <div key={p.id} className="flex items-center justify-between text-xs">
                  <div style={{ color: COLORS.ink + "80" }}>
                    Order {p.orderId} &middot; {new Date(p.date).toLocaleDateString("en-IN")}
                    <div className="text-[10px]" style={{ color: COLORS.ink + "60" }}>
                      {fmt(p.gross)} gross − {fmt(p.commission)} platform fee
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="mono font-bold" style={{ color: COLORS.steel }}>+{fmt(p.net)}</div>
                    <div className="text-[9px] uppercase font-bold" style={{ color: COLORS.steel }}>Credited to {maskedAccount}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
          <div className="text-[10px] mt-3" style={{ color: COLORS.ink + "60" }}>
            {PLATFORM_COMMISSION_PCT}% platform fee is deducted automatically before settlement. Demo mode — real payouts would route through a marketplace split-payment partner (e.g. Razorpay Route, Cashfree Vendor Payouts).
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- Vendor panel ----------
function VendorPanel({ products, vendors, vendorId, session, payouts, addProduct, updateOffer, deleteOffer, onLogout, t }) {
  const tr = t || ((k) => TRANSLATIONS[k]?.en || k);
  const vendor = vendorById(vendors, vendorId);
  const myListings = [];
  products.forEach((p) => {
    const offer = p.offers.find((o) => o.vendorId === vendorId);
    if (offer) myListings.push({ product: p, offer, cat: catById(p.cat) });
  });

  // surface the most urgent items first: out of stock, then low stock, then everything else
  const rank = { out: 0, low: 1, ok: 2 };
  const sortedListings = [...myListings].sort(
    (a, b) => rank[stockStatus(a.offer, a.cat)] - rank[stockStatus(b.offer, b.cat)]
  );

  const outCount = myListings.filter((l) => stockStatus(l.offer, l.cat) === "out").length;
  const lowCount = myListings.filter((l) => stockStatus(l.offer, l.cat) === "low").length;
  const staleCount = myListings.filter((l) => !isFreshStock(l.offer.updatedAt)).length;

  const [showAdd, setShowAdd] = useState(false);
  const [editingKey, setEditingKey] = useState(null);
  const [editPrice, setEditPrice] = useState("");
  const [editStock, setEditStock] = useState("");
  const [editGstScheme, setEditGstScheme] = useState("itc");

  function startEdit(productId, offer) {
    setEditingKey(productId);
    setEditPrice(String(offer.price));
    setEditStock(String(offer.stock));
    setEditGstScheme(offer.gstScheme || "itc");
  }
  function saveEdit(productId, hasGstScheme) {
    const changes = { price: Number(editPrice) || 0, stock: Number(editStock) || 0 };
    if (hasGstScheme) changes.gstScheme = editGstScheme;
    updateOffer(productId, vendorId, changes);
    setEditingKey(null);
  }
  function quickRestock(productId, currentStock, step) {
    updateOffer(productId, vendorId, { stock: currentStock + step });
  }

  if (!vendor) return null;

  return (
    <div className="max-w-5xl mx-auto px-4 pb-16">
      <div className="pt-5 pb-4 flex items-start justify-between">
        <div>
          <div className="text-xs font-semibold mb-1 flex items-center gap-2" style={{ color: COLORS.steel }}>
            {tr("vendor_dashboard").toUpperCase()}
            {session.verified ? (
              <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded flex items-center gap-0.5" style={{ background: COLORS.steel + "18", color: COLORS.steel }}>
                <Check size={9} /> GST verified
              </span>
            ) : (
              <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded" style={{ background: COLORS.ink + "10", color: COLORS.ink + "70" }}>
                Unverified
              </span>
            )}
          </div>
          <div className="disp text-2xl font-800" style={{ color: COLORS.ink }}>{vendor.name}</div>
          <div className="flex items-center gap-3 mt-1 text-xs flex-wrap" style={{ color: COLORS.ink + "80" }}>
            <span className="flex items-center gap-1"><Star size={12} fill={COLORS.steel} color={COLORS.steel} /> {vendor.rating || "New"} {vendor.rating ? "rating" : ""}</span>
            <span className="flex items-center gap-1"><Truck size={12} /> {vendor.deliveryDays}-day fulfillment</span>
            <span className="mono">{vendor.gstin ? `GSTIN ${vendor.gstin}` : `Mobile ${session.mobile}`}</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-2 shrink-0">
          <button
            onClick={() => setShowAdd((s) => !s)}
            style={{ background: COLORS.orange }}
            className="text-white text-xs font-bold rounded-md px-3 py-2 flex items-center gap-1.5"
          >
            <PackagePlus size={14} /> {showAdd ? "Close" : tr("add_product")}
          </button>
          <button onClick={onLogout} className="text-[11px] font-semibold" style={{ color: COLORS.ink + "60" }}>
            {tr("log_out")}
          </button>
        </div>
      </div>

      {session.isNew && (
        <div className="rounded-lg p-3.5 mb-4 flex items-start gap-2.5" style={{ background: COLORS.steel + "10", border: `1px solid ${COLORS.steel}30` }}>
          <Zap size={16} style={{ color: COLORS.steel }} className="mt-0.5 shrink-0" />
          <div className="text-sm" style={{ color: COLORS.ink }}>
            <span className="font-bold">Welcome to BuildKart!</span> Your vendor profile was created automatically from your mobile number
            {session.verified ? " and verified GSTIN" : ""}. Add your first product listing below to start selling.
          </div>
        </div>
      )}

      <EarningsPanel vendor={vendor} payouts={payouts} />


      {showAdd && (
        <AddProductForm
          vendorId={vendorId}
          onCancel={() => setShowAdd(false)}
          onAdd={(prod) => { addProduct(prod); setShowAdd(false); }}
        />
      )}

      {(outCount > 0 || lowCount > 0) && (
        <div
          className="rounded-lg p-3.5 mb-4 flex items-start gap-2.5"
          style={{ background: COLORS.orange + "12", border: `1px solid ${COLORS.orange}40` }}
        >
          <AlertTriangle size={16} style={{ color: COLORS.orange }} className="mt-0.5 shrink-0" />
          <div className="text-sm" style={{ color: COLORS.ink }}>
            <span className="font-bold">
              {outCount > 0 && `${outCount} product${outCount > 1 ? "s" : ""} out of stock`}
              {outCount > 0 && lowCount > 0 && ", "}
              {lowCount > 0 && `${lowCount} running low`}
            </span>
            {" — "}buyers can't order these until you restock. Update below to stay visible in search results.
          </div>
        </div>
      )}

      <div className="grid grid-cols-3 gap-3 mb-6 mt-2">
        <StatCard label="Listed products" value={myListings.length} />
        <StatCard label="Low / out of stock" value={outCount + lowCount} highlight={outCount + lowCount > 0} />
        <StatCard label="Stock not updated 24h+" value={staleCount} highlight={staleCount > 0} />
      </div>

      <div className="flex items-center justify-between mb-2">
        <div className="disp text-sm font-700 uppercase tracking-wide" style={{ color: COLORS.steel }}>Your inventory</div>
        <div className="text-[10px]" style={{ color: COLORS.ink + "60" }}>Sorted by what needs attention first</div>
      </div>

      <div className="bg-white rounded-lg border border-black/5 divide-y divide-black/5">
        {sortedListings.map(({ product: p, offer, cat }) => {
          const lowest = Math.min(...p.offers.map((o) => o.price));
          const isBest = offer.price === lowest;
          const isEditing = editingKey === p.id;
          const status = stockStatus(offer, cat);
          const fresh = isFreshStock(offer.updatedAt);

          return (
            <div key={p.id} className="px-4 py-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="min-w-0">
                  <div className="text-sm font-semibold flex items-center gap-1.5 flex-wrap" style={{ color: COLORS.ink }}>
                    <Package size={13} style={{ color: COLORS.orange }} /> {p.name}
                    {status === "out" && (
                      <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded" style={{ background: COLORS.orange, color: "white" }}>
                        Out of stock
                      </span>
                    )}
                    {status === "low" && (
                      <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded flex items-center gap-0.5" style={{ background: COLORS.orange + "20", color: COLORS.orange }}>
                        <AlertTriangle size={9} /> Low stock
                      </span>
                    )}
                    {!isBest && status === "ok" && (
                      <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded" style={{ background: COLORS.ink + "10", color: COLORS.ink + "90" }}>
                        undercut by competitor
                      </span>
                    )}
                    {fresh ? (
                      <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded flex items-center gap-0.5" style={{ background: COLORS.steel + "18", color: COLORS.steel }}>
                        <Zap size={9} /> Fresh — visible boost
                      </span>
                    ) : (
                      <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded flex items-center gap-0.5" style={{ background: COLORS.ink + "08", color: COLORS.ink + "70" }}>
                        <Clock size={9} /> stale {timeAgo(offer.updatedAt)}
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] mt-0.5" style={{ color: COLORS.ink + "70" }}>
                    {cat.unit} &middot; HSN {cat.hsn} &middot; GST {effectiveGstPct(offer, cat)}%{cat.hasGstScheme ? (offer.gstScheme === "composition" ? " (composition, no ITC)" : " (with ITC)") : ""} &middot; low-stock alert below {cat.lowStock.toLocaleString()}
                  </div>
                </div>

                {!isEditing && (
                  <div className="flex items-center gap-2 shrink-0 pl-2">
                    <div className="text-right">
                      <div className="mono font-bold text-sm" style={{ color: isBest ? COLORS.orange : COLORS.ink }}>{fmt(offer.price)}</div>
                      <div className="text-[10px]" style={{ color: status === "out" ? COLORS.orange : COLORS.ink + "60" }}>
                        Stock: {offer.stock.toLocaleString()}
                      </div>
                    </div>
                    <button
                      onClick={() => quickRestock(p.id, offer.stock, cat.restockStep)}
                      title={`Quick restock +${cat.restockStep.toLocaleString()}`}
                      className="p-1.5 rounded-md flex items-center gap-1"
                      style={{ background: COLORS.steel + "15" }}
                    >
                      <RefreshCw size={13} style={{ color: COLORS.steel }} />
                      <span className="text-[10px] font-bold" style={{ color: COLORS.steel }}>+{cat.restockStep.toLocaleString()}</span>
                    </button>
                    <button onClick={() => startEdit(p.id, offer)} className="p-1.5 rounded-md" style={{ background: COLORS.ink + "08" }}>
                      <Pencil size={13} style={{ color: COLORS.steel }} />
                    </button>
                    <button onClick={() => deleteOffer(p.id, vendorId)} className="p-1.5 rounded-md" style={{ background: COLORS.ink + "08" }}>
                      <Trash2 size={13} style={{ color: COLORS.orange }} />
                    </button>
                  </div>
                )}
              </div>

              {isEditing && (
                <div className="mt-2.5 flex items-end gap-2 flex-wrap">
                  <div>
                    <label className="block text-[10px] mb-0.5" style={{ color: COLORS.ink + "70" }}>Price ({cat.unit})</label>
                    <input value={editPrice} onChange={(e) => setEditPrice(e.target.value)} type="number"
                      className="mono w-28 border border-black/10 rounded-md px-2 py-1.5 text-sm outline-none focus:ring-2" style={{ "--tw-ring-color": COLORS.orange }} />
                  </div>
                  <div>
                    <label className="block text-[10px] mb-0.5" style={{ color: COLORS.ink + "70" }}>Stock</label>
                    <input value={editStock} onChange={(e) => setEditStock(e.target.value)} type="number"
                      className="mono w-24 border border-black/10 rounded-md px-2 py-1.5 text-sm outline-none focus:ring-2" style={{ "--tw-ring-color": COLORS.orange }} />
                  </div>
                  {cat.hasGstScheme && (
                    <div>
                      <label className="block text-[10px] mb-0.5" style={{ color: COLORS.ink + "70" }}>GST scheme</label>
                      <select
                        value={editGstScheme} onChange={(e) => setEditGstScheme(e.target.value)}
                        className="border border-black/10 rounded-md px-2 py-1.5 text-sm outline-none focus:ring-2 bg-white"
                        style={{ "--tw-ring-color": COLORS.orange }}
                      >
                        <option value="itc">{cat.gst}% with ITC</option>
                        <option value="composition">{cat.gstCompositionRate}% composition (no ITC)</option>
                      </select>
                    </div>
                  )}
                  <button onClick={() => saveEdit(p.id, cat.hasGstScheme)} style={{ background: COLORS.orange }} className="text-white text-xs font-bold rounded-md px-3 py-2 flex items-center gap-1">
                    <Save size={13} /> Save
                  </button>
                  <button onClick={() => setEditingKey(null)} className="text-xs font-semibold px-3 py-2" style={{ color: COLORS.ink + "70" }}>
                    Cancel
                  </button>
                </div>
              )}
            </div>
          );
        })}
        {myListings.length === 0 && (
          <div className="text-center py-10 text-sm" style={{ color: COLORS.ink + "70" }}>
            No listings yet — add your first product above.
          </div>
        )}
      </div>

      <div className="mt-4 text-xs px-1 flex items-start gap-1.5" style={{ color: COLORS.ink + "60" }}>
        <Zap size={12} className="mt-0.5 shrink-0" style={{ color: COLORS.steel }} />
        Vendors who keep stock updated within the last 24 hours get a "Fresh stock" badge that buyers see first — stale or unmanaged listings sink below active ones with the same price.
      </div>
    </div>
  );
}

function AddProductForm({ vendorId, onAdd, onCancel }) {
  const [name, setName] = useState("");
  const [cat, setCat] = useState(CATEGORIES[0].id);
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");
  const [gstScheme, setGstScheme] = useState("itc");

  function submit() {
    if (!name.trim() || !price || !stock) return;
    const catInfo = catById(cat);
    onAdd({
      id: "p" + Date.now(),
      cat,
      name: name.trim(),
      offers: [{
        vendorId, price: Number(price), stock: Number(stock), updatedAt: new Date(),
        ...(catInfo.hasGstScheme ? { gstScheme } : {}),
      }],
    });
  }

  const catInfo = catById(cat);

  return (
    <div className="bg-white rounded-lg border border-black/5 p-4 mb-4">
      <div className="disp text-sm font-700 uppercase tracking-wide mb-3" style={{ color: COLORS.steel }}>New product listing</div>
      <div className="grid grid-cols-2 gap-3 mb-3">
        <div className="col-span-2">
          <label className="block text-[10px] mb-1" style={{ color: COLORS.ink + "70" }}>Product name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. AAC Blocks 600x200x100"
            className="w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2" style={{ "--tw-ring-color": COLORS.orange }} />
        </div>
        <div>
          <label className="block text-[10px] mb-1" style={{ color: COLORS.ink + "70" }}>Category</label>
          <select value={cat} onChange={(e) => setCat(e.target.value)}
            className="w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2" style={{ "--tw-ring-color": COLORS.orange }}>
            {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-[10px] mb-1" style={{ color: COLORS.ink + "70" }}>HSN / GST</label>
          <div className="mono border border-black/10 rounded-md px-3 py-2 text-sm" style={{ color: COLORS.ink + "80", background: COLORS.concrete }}>
            {catInfo.hsn} &middot; {catInfo.hasGstScheme ? `${catInfo.gstCompositionRate}–${catInfo.gst}%*` : `${catInfo.gst}%`}
          </div>
        </div>
        {catInfo.hasGstScheme && (
          <div className="col-span-2">
            <label className="block text-[10px] mb-1" style={{ color: COLORS.ink + "70" }}>GST scheme</label>
            <select
              value={gstScheme} onChange={(e) => setGstScheme(e.target.value)}
              className="w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2 bg-white"
              style={{ "--tw-ring-color": COLORS.orange }}
            >
              <option value="itc">{catInfo.gst}% with Input Tax Credit (standard)</option>
              <option value="composition">{catInfo.gstCompositionRate}% composition scheme (no ITC, lower rate)</option>
            </select>
            <div className="text-[10px] mt-1" style={{ color: COLORS.ink + "60" }}>
              Composition scheme lowers the GST charged to buyers, but you can't claim input tax credit on your own material purchases. Per CBIC Notification 14/2025.
            </div>
          </div>
        )}
        <div>
          <label className="block text-[10px] mb-1" style={{ color: COLORS.ink + "70" }}>Price ({catInfo.unit})</label>
          <input value={price} onChange={(e) => setPrice(e.target.value)} type="number" placeholder="0"
            className="mono w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2" style={{ "--tw-ring-color": COLORS.orange }} />
        </div>
        <div>
          <label className="block text-[10px] mb-1" style={{ color: COLORS.ink + "70" }}>Stock quantity</label>
          <input value={stock} onChange={(e) => setStock(e.target.value)} type="number" placeholder="0"
            className="mono w-full border border-black/10 rounded-md px-3 py-2 text-sm outline-none focus:ring-2" style={{ "--tw-ring-color": COLORS.orange }} />
        </div>
      </div>
      <div className="flex gap-2">
        <button onClick={submit} style={{ background: COLORS.orange }} className="text-white text-xs font-bold rounded-md px-4 py-2">
          Publish listing
        </button>
        <button onClick={onCancel} className="text-xs font-semibold px-4 py-2" style={{ color: COLORS.ink + "70" }}>
          Cancel
        </button>
      </div>
    </div>
  );
}

function StatCard({ label, value, highlight }) {
  return (
    <div className="bg-white rounded-lg border border-black/5 p-3.5">
      <div className="mono font-bold text-xl" style={{ color: highlight ? COLORS.orange : COLORS.orange }}>{value}</div>
      <div className="text-[10px] uppercase tracking-wide mt-0.5" style={{ color: highlight ? COLORS.orange : COLORS.ink + "70" }}>{label}</div>
    </div>
  );
}
