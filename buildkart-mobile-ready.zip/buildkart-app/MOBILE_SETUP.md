# BuildKart — Mobile App Setup (iOS + Android)

This project has been prepared for conversion into a real mobile app using **Capacitor**.

## What was changed

- Added Capacitor configuration (`capacitor.config.json`)
- Updated `package.json` with Capacitor packages and helpful scripts
- Improved `index.html` for better mobile experience (safe area, no zoom, status bar color)

## Requirements on your computer

### For Android
- Node.js 18+
- Android Studio (latest)
- Java 17+

### For iOS (Mac only)
- Node.js 18+
- Xcode 15+
- CocoaPods (`sudo gem install cocoapods`)

---

## Step-by-step setup

### 1. Install dependencies

```bash
cd buildkart-app
npm install
```

### 2. Build the web app and sync with native projects

```bash
npm run mobile:sync
```

This will:
1. Build the React app (`npm run build`)
2. Create `android/` and `ios/` folders
3. Copy the web assets into the native projects

### 3. Add the native platforms (first time only)

```bash
npx cap add android
npx cap add ios
```

Then run sync again:

```bash
npm run mobile:sync
```

### 4. Open in Android Studio / Xcode

**Android:**
```bash
npm run mobile:android
```
or
```bash
npx cap open android
```

**iOS (Mac only):**
```bash
npm run mobile:ios
```
or
```bash
npx cap open ios
```

### 5. Run on device / emulator

From Android Studio or Xcode, click the Run button.

Or from terminal:

```bash
# Android
npm run mobile:run:android

# iOS
npm run mobile:run:ios
```

---

## Useful commands

| Command | What it does |
|---------|--------------|
| `npm run dev` | Run web version in browser |
| `npm run build` | Build web assets |
| `npm run mobile:sync` | Build + copy to native projects |
| `npm run mobile:android` | Sync + open Android Studio |
| `npm run mobile:ios` | Sync + open Xcode |

---

## App details

- **App ID**: `com.buildkart.app`
- **App Name**: BuildKart
- **Splash / Status bar color**: Orange (`#F97316`)

---

## Next improvements you can do

1. Add app icons (replace default Capacitor icons)
2. Configure push notifications
3. Use native Geolocation instead of browser API
4. Use native Camera for the brick estimator
5. Publish to Google Play Store and Apple App Store

---

## Need help?

Just tell me which step you are on or any error you see, and I will guide you.
